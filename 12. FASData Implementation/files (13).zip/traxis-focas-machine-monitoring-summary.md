# FANUC FOCAS Machine Monitoring Project
## Traxis Manufacturing - Research Summary

**Date:** January 28, 2026  
**Purpose:** Machine utilization tracking for productivity-based pay system  
**Integration Target:** ProShop ERP, existing clock feedback display, Airtable automation

---

## Executive Summary

Traxis has 9 CNC machines, 8 of which have FANUC controls with Ethernet already connected for DNC. The FOCAS protocol provides direct access to machine status, spindle speed, program numbers, and other data needed for utilization tracking. After evaluating commercial options (FASData, Scytec, MachineMetrics) against building a custom solution, **building on FOCAS directly** is recommended given Traxis's technical capabilities and need for deep integration with existing systems.

---

## Machine Inventory

| Machine | Description | Control | FOCAS DLL Required | Notes |
|---------|-------------|---------|-------------------|-------|
| Mill-1 | Haas VF5 | Classic | N/A | Not FANUC - needs MTConnect adapter (~$300-500) or skip |
| Mill-2 | Smec | FANUC 0i-MF | fwlib30i.dll | ✓ Ready |
| Mill-3 | Smec | FANUC 0i-MF | fwlib30i.dll | ✓ Ready |
| Mill-4 | Black Robodrill | FANUC 0i-MC | fwlib30i.dll | ✓ Ready |
| Mill-5 | White Robodrill | FANUC 16i | Fwlib160.dll | ✓ Ready |
| Mill-6 | Chevalier | FANUC 0i-MF | fwlib30i.dll | ✓ Ready |
| Mill-7 | 5-axis Robodrill | FANUC | fwlib30i.dll | ✓ Ready |
| Mill-8 | Hyundai-Wia KF5600II | FANUC i-series | fwlib30i.dll | ✓ Ready |
| T2 | YCM NTC1600LY Lathe | FANUC 0i-MF | fwlib30i.dll | ✓ Ready |

**Result:** 8 of 9 machines can use FOCAS. Ethernet already connected for DNC.

---

## Buy vs Build Analysis

### Commercial Options

| Product | Pricing Model | Estimated Annual Cost | Pros | Cons |
|---------|--------------|----------------------|------|------|
| **FANUC FASData** | One-time license | Unknown (contact FANUC) | Native FOCAS, free trial | North America only, limited customization |
| **Scytec DataXchange** | $45-52/machine/month | ~$5,400/year + $1,000 setup | Proven, good support | Ongoing cost, less control |
| **MachineMetrics** | ~$100/machine/month | ~$10,800/year | Feature-rich | Expensive, overkill for utilization |
| **Predator MDC** | Quote-based | ~$8,000-15,000/year | Enterprise features | Complex, expensive |

### Custom Build Estimate

| Task | Hours |
|------|-------|
| FOCAS library setup & testing | 4-8 |
| Polling script for 8 machines | 8-16 |
| Database + utilization calculations | 4-8 |
| Basic web dashboard | 8-16 |
| Integration with clock feedback display | 4-8 |
| **Total** | **28-56 hours** |

### Recommendation: Build Custom

**Rationale:**
- Traxis already has technical infrastructure (ProShop API, Airtable, Document AI pipelines)
- Direct integration with productivity pay system and clock feedback display
- No ongoing licensing costs
- Complete control over data and calculations
- FASData uses the same FOCAS DLLs internally - you're just cutting out the middleman

---

## FOCAS Protocol Overview

**FOCAS** = FANUC Open CNC API Specification

### Connection Details
- **Protocol:** TCP/IP over Ethernet
- **Default Port:** 8193
- **Library:** Windows DLLs (32-bit)

### Data Available via FOCAS

| Function | Data | Use Case |
|----------|------|----------|
| `cnc_statinfo()` | Machine state (run/stop/hold/alarm) | Utilization tracking |
| `cnc_rdprgnum()` | Running program number | Job tracking |
| `cnc_acts()` | Actual spindle speed (RPM) | Cycle detection |
| `cnc_rdspeed()` | Feed rate | Performance monitoring |
| `cnc_absolute()` | Axis positions | Motion tracking |
| `cnc_alarm()` | Active alarms | Downtime coding |
| `cnc_rdcncid()` | Unique machine ID | Asset identification |
| `cnc_sysinfo()` | Control type/version | Inventory management |

### Machine Status Values (ODBST structure)

**Run Status (`run`):**
- 0 = STOP (***)
- 1 = HOLD
- 2 = START (Running)
- 3 = MSTR (M/S/T/B executing)
- 4 = RSTR (Restart)

**Mode (`aut`):**
- 0 = MDI
- 1 = MEM (Auto)
- 2 = EDIT
- 3 = HANDLE
- 4 = JOG

**Motion (`motion`):**
- 0 = No motion (***)
- 1 = MTN (Axis moving)
- 2 = DWL (Dwell)

---

## FOCAS Library Evaluation

### Source
**GitHub Repository:** github.com/strangesast/fwlib  
- 146 stars, 82 forks
- Actively maintained
- Includes examples in C, Python, Go

### Verification Results

| Check | Status |
|-------|--------|
| VirusTotal scan | ✓ Clean |
| FANUC copyright strings | ✓ Found `Software\FANUC\FOCAS\LIBOPT` |
| Header file completeness | ✓ 16,043 lines, all standard functions |
| File sizes | ✓ Consistent with official library |
| Example code | ✓ Working examples included |

### Files for Traxis Machines

| File | Size | Purpose |
|------|------|---------|
| Fwlib32.dll | 532 KB | Main library (always required) |
| fwlibe1.dll | 832 KB | Ethernet/TCP support (always required) |
| fwlib30i.dll | 1.8 MB | 0i-MF, 0i-MC, 0i-F, 30i, 31i series |
| Fwlib160.dll | 836 KB | 16i, 18i, 21i series |

### SHA256 Hashes (for verification)

```
Fwlib32.dll:   2e77a1639b0d10bd0760232478458deeb5abd1e7242de7ecb4fa1ff8835e57d2
fwlibe1.dll:   a599ac364043b40a236fed54eed588203f24f8a48d604fcbf698ff5d5b37635e
fwlib30i.dll:  e361f53030e9958964447a0f0d6bb06f36f1cc8c16cd6858a9bc90b0ee5ee108
Fwlib160.dll:  c0a7201e9258c446af198aff33b48501d715451fe88564665b3059e64142821e
```

---

## CNC Configuration Requirements

### Enable FOCAS on Each Machine

1. Press **[SYSTEM]** → **[EMBED PORT]** or **[ETHER BOARD]**
2. Under **[COMMON]**: Verify/set IP address
3. Under **[FOCAS2]**: Set **TCP PORT NUMBER = 8193**
   - ⚠️ If this shows 0, FOCAS is disabled!

### Network Verification (from shop PC)

```powershell
# Test ping
ping 192.168.x.x

# Test FOCAS port
Test-NetConnection -ComputerName 192.168.x.x -Port 8193
```

---

## Test Package Contents

A ready-to-run test package was prepared: `focas-test.zip`

| File | Purpose |
|------|---------|
| Program.cs | C# test application |
| FocasTest.csproj | Project file (targets x86 for 32-bit DLLs) |
| README.md | Detailed instructions |
| check-prerequisites.ps1 | Pre-flight verification script |
| test.bat | Quick run helper |
| *.dll | All required FOCAS libraries |

### Running the Test

```bash
# Prerequisites: .NET 6.0 SDK (x86 version)
# https://dotnet.microsoft.com/download/dotnet/6.0

# Extract zip, open command prompt in folder
dotnet run 192.168.1.100   # Replace with machine IP
```

### Expected Output (Success)

```
[2] FOCAS Connection...
    ✓ Connected! Handle: 1

[4] Reading System Info...
    ✓ CNC Type: 0F
    ✓ Series: 0i-F

[5] Reading Machine Status...
    ✓ Mode: MEM (Auto)
    ✓ Run Status: STOP (***)
    ✓ Alarm: None

[7] Reading Spindle Speed...
    ✓ Actual Spindle Speed: 0 RPM

TEST COMPLETE - ALL CHECKS PASSED ✓
```

---

## Common FOCAS Errors

| Error Code | Meaning | Solution |
|------------|---------|----------|
| -2 | Socket error | Check network cable/connection |
| -7 | Version mismatch | DLL may not match control series |
| -8 | Socket creation error | Check firewall, run as admin |
| -15 | Series DLL not found | Add fwlib30i.dll or Fwlib160.dll |
| -16 | Connection refused/timeout | Enable FOCAS on CNC (port 8193) |

---

## Proposed Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Shop Floor                                │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐           │
│  │ Mill-2  │ │ Mill-3  │ │ Mill-4  │ │  ...    │           │
│  │ 0i-MF   │ │ 0i-MF   │ │ 0i-MC   │ │         │           │
│  └────┬────┘ └────┬────┘ └────┬────┘ └────┬────┘           │
│       │           │           │           │                 │
│       └───────────┴───────────┴───────────┘                 │
│                       │                                      │
│                 Port 8193 (FOCAS)                            │
│                       │                                      │
│              ┌────────▼────────┐                            │
│              │  Collector PC   │                            │
│              │  (C# Service)   │                            │
│              │  - Poll every   │                            │
│              │    5-10 seconds │                            │
│              │  - SQLite/SQL   │                            │
│              └────────┬────────┘                            │
└───────────────────────┼─────────────────────────────────────┘
                        │
        ┌───────────────┼───────────────┐
        │               │               │
        ▼               ▼               ▼
┌───────────────┐ ┌───────────┐ ┌─────────────────┐
│ Clock Display │ │  ProShop  │ │ Productivity    │
│ (Existing)    │ │  ERP API  │ │ Pay Calculation │
└───────────────┘ └───────────┘ └─────────────────┘
```

---

## Next Steps

### Immediate (Tomorrow)
- [ ] Run FOCAS test on one machine (start with a Robodrill)
- [ ] Document IP addresses for all 8 FANUC machines
- [ ] Verify FOCAS port 8193 enabled on each control

### Short Term (This Week)
- [ ] Test all 8 machines, record CNC IDs
- [ ] Design utilization calculation logic
- [ ] Decide on database (SQLite for simple, SQL Server for ProShop integration)

### Medium Term (Next 2-4 Weeks)
- [ ] Build polling service (C# Windows Service)
- [ ] Create utilization dashboard
- [ ] Integrate with clock feedback display
- [ ] Connect to ProShop for job context

### Haas VF5 (Deferred)
- Skip initially, monitor 8/9 machines
- Options later: MTConnect adapter ($300-500) or Q-codes over RS-232

---

## Resources

### FANUC Contacts
- **FANUC America:** 1-888-FANUC-US (888-326-8287)
- **FASData Info:** fanucamerica.com/products/cnc/cnc-software/fasdata
- **Official FOCAS Library CD:** Part # A02B-0207-K737 (~$100-200)

### Documentation
- **inventcom.net:** Free FOCAS function documentation
  - inventcom.net/fanuc-focas-library
  - inventcom.net/support/fanuc/focas-library-cd
- **FOCAS Library CD Contents:** inventcom.net/support/fanuc/focas-library-cd

### Code Resources
- **FOCAS DLLs (verified):** github.com/strangesast/fwlib
- **C# Wrapper Example:** github.com/versex799/FanucFocasTutorial
- **Tutorial Series:** hierthinking.com (search "Fanuc Focas")

### Alternative Repos
- github.com/wheeliar/FANUC_Focas_API
- github.com/johnmichaloski/MTConnectGadgets

---

## Key Insights

1. **FASData uses the same DLLs** - Commercial software just wraps FOCAS. Building direct gives you the same capabilities with full control.

2. **0i-MF uses fwlib30i.dll** - Despite being "0i" series, the MF variant requires the 30i library (it's part of the 0i-F family).

3. **Port 8193 is the gotcha** - Most connection failures are because FOCAS isn't enabled on the CNC. Check the TCP PORT NUMBER setting.

4. **32-bit DLLs require x86 target** - When building C# apps, must target x86 platform or use 32-bit .NET SDK.

5. **Polling is fine for utilization** - You don't need real-time streaming. Polling every 5-10 seconds is plenty for calculating utilization percentages.

---

*Document prepared from research session, January 28, 2026*
