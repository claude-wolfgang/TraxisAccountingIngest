# FOCAS Monitor Deployment Guide

**Last Updated:** 2026-01-30

---

## Overview

A Windows service that polls FANUC CNC machines via FOCAS protocol every 60 seconds and stores data in SQLite for utilization tracking.

---

## Quick Start - Test on Main PC First

### Step 1: Verify Files

Your project folder should be at:
```
D:\Dropbox\MACHINE COMM Traxis\Proshop Automation and Claude Projects\12. FASData Implementation\FocasMonitor
```

Required files:
```
FocasMonitor.csproj      ← Project file
Program.cs               ← Entry point
MonitoringService.cs     ← Polling logic
Database.cs              ← SQLite handling
Focas.cs                 ← FOCAS DLL wrapper
machines.json            ← Machine configuration
Fwlib32.dll              ← FOCAS DLLs (copy from focas-test folder)
fwlib30i.dll
fwlib0iD.dll
Fwlib0iB.dll
Fwlib160.dll
fwlibe1.dll
Fwlib0i.dll
```

### Step 2: Copy FOCAS DLLs

If the FOCAS DLLs aren't in the FocasMonitor folder yet:
```cmd
copy "..\focas-test\*.dll" .
```

### Step 3: Test Run

```cmd
cd "D:\Dropbox\MACHINE COMM Traxis\Proshop Automation and Claude Projects\12. FASData Implementation\FocasMonitor"
dotnet run
```

You should see:
```
=====================================================
  FOCAS Machine Monitor - Traxis Manufacturing
=====================================================

Looking for config at: D:\Dropbox\...\FocasMonitor\machines.json
Loaded 8 machines from config
  - T2: YCM NTC1600LY (10.1.1.82) Enabled=True
  - M2: FANUC Mill 2 (10.1.1.159) Enabled=True
  ...
info: FocasMonitor.MonitoringService[0]
      FOCAS Monitoring Service started
info: FocasMonitor.MonitoringService[0]
      Database: C:\FASData\monitoring.db
info: FocasMonitor.MonitoringService[0]
      Poll interval: 60 seconds
info: FocasMonitor.MonitoringService[0]
      Machines configured: 5
```

Press Ctrl+C to stop.

---

## Deploy to Collector PC

### Step 1: Build Self-Contained Package

On your main PC:
```cmd
cd "D:\Dropbox\MACHINE COMM Traxis\Proshop Automation and Claude Projects\12. FASData Implementation\FocasMonitor"
dotnet publish FocasMonitor.csproj -c Release -r win-x86 --self-contained true -o publish
```

### Step 2: Copy to USB

```cmd
xcopy publish E:\FocasMonitor\ /E /I
```

### Step 3: On Collector PC

1. Copy `E:\FocasMonitor` to `C:\FocasMonitor`
2. Test it:
```cmd
C:\FocasMonitor\FocasMonitor.exe
```

### Step 4: Install as Windows Service

Run as Administrator:
```cmd
sc create "FocasMonitor" binPath= "C:\FocasMonitor\FocasMonitor.exe" start= auto DisplayName= "FOCAS Machine Monitor"
sc description "FocasMonitor" "Monitors FANUC CNC machines via FOCAS protocol"
sc start "FocasMonitor"
```

---

## Configuration

Edit `machines.json` to add/modify machines:

```json
{
  "pollIntervalSeconds": 60,
  "databasePath": "C:\\FASData\\monitoring.db",
  "logPath": "C:\\FASData\\logs",
  "machines": [
    {
      "id": "M2",
      "name": "FANUC Mill 2",
      "type": "Mill",
      "ip": "10.1.1.159",
      "port": 8193,
      "enabled": true
    }
  ]
}
```

After editing, restart the service:
```cmd
sc stop FocasMonitor
sc start FocasMonitor
```

---

## Machine Inventory

| ID | Name | Type | IP | Port | Status |
|----|------|------|-----|------|--------|
| T2 | YCM NTC1600LY | Lathe | 10.1.1.82 | 8193 | ✅ Tested |
| M2 | FANUC Mill 2 | Mill | 10.1.1.159 | 8193 | ✅ Tested |
| M3 | FANUC Mill 3 | Mill | 10.1.1.118 | 8193 | 🔧 Ethernet adapter failed |
| M4 | Robodrill 4 | Mill | — | 8193 | ⏳ Needs Ethernet |
| M5 | Robodrill 5 | Mill | — | 8193 | ⏳ Needs Ethernet |
| M6 | FANUC Mill 6 | Mill | 10.1.1.106 | 8193 | ✅ Tested |
| M7 | Robodrill 7 | Mill | — | 8193 | ⏳ Needs Ethernet |
| M8 | FANUC Mill 8 | Mill | 10.1.1.202 | 8193 | ✅ Tested |

---

## Data Storage

**Location:** `C:\FASData\monitoring.db`

**Schema:**
```sql
CREATE TABLE machine_samples (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    machine_id TEXT,
    machine_name TEXT,
    connected INTEGER,
    error_message TEXT,
    mode TEXT,           -- MEM, MDI, JOG, etc.
    run_status TEXT,     -- STOP, STRT, HOLD
    motion TEXT,         -- ***, MTN, DWL
    program_number INTEGER,
    main_program INTEGER,
    spindle_speed INTEGER,
    feed_rate INTEGER,
    spindle_override INTEGER,
    feedrate_override INTEGER,
    emergency INTEGER,
    alarm INTEGER,
    alarm_message TEXT,
    axis_x INTEGER,
    axis_y INTEGER,
    axis_z INTEGER
);
```

**Storage estimate:** ~500 MB/year for 9 machines at 1-minute polling.

---

## Querying Data

Use DB Browser for SQLite or any SQLite tool.

**Today's data:**
```sql
SELECT * FROM machine_samples 
WHERE timestamp >= date('now')
ORDER BY timestamp DESC;
```

**Daily utilization:**
```sql
SELECT 
    machine_id,
    date(timestamp) as day,
    COUNT(*) as total_samples,
    SUM(CASE WHEN run_status = 'STRT' THEN 1 ELSE 0 END) as running,
    ROUND(100.0 * SUM(CASE WHEN run_status = 'STRT' THEN 1 ELSE 0 END) / COUNT(*), 1) as utilization_pct
FROM machine_samples
WHERE connected = 1
GROUP BY machine_id, date(timestamp)
ORDER BY day DESC, machine_id;
```

**Weekly summary:**
```sql
SELECT 
    machine_id,
    strftime('%Y-W%W', timestamp) as week,
    COUNT(*) as samples,
    ROUND(100.0 * SUM(CASE WHEN spindle_speed > 0 THEN 1 ELSE 0 END) / COUNT(*), 1) as spindle_utilization
FROM machine_samples
WHERE connected = 1
GROUP BY machine_id, week
ORDER BY week DESC, machine_id;
```

---

## Service Management

```cmd
sc query FocasMonitor      # Check status
sc stop FocasMonitor       # Stop
sc start FocasMonitor      # Start
sc delete FocasMonitor     # Uninstall
```

Or use `services.msc` GUI.

---

## Troubleshooting

### "Machines configured: 0"

The config file isn't being found or parsed. Check:
1. `machines.json` is in the same folder as the .exe
2. JSON is valid (no trailing commas, proper quotes)
3. Look at console output for "Looking for config at:" path

### Connection failures

1. Verify machine is on: `ping 10.1.1.xxx`
2. Verify FOCAS port: `Test-NetConnection -ComputerName 10.1.1.xxx -Port 8193`
3. Check FOCAS is enabled on CNC: [SYSTEM] → [EMBED PORT] → [FOCAS2]

### Service won't start

1. Run .exe manually first to see errors
2. Check Windows Event Viewer → Application logs
3. Verify all DLLs are present

### Missing DLLs

Copy from focas-test folder or download from:
https://github.com/strangesast/fwlib/archive/refs/heads/master.zip

---

## Files Checklist

After `dotnet publish`, the `publish` folder should contain:

- [x] FocasMonitor.exe
- [x] FocasMonitor.dll
- [x] machines.json
- [x] Fwlib32.dll
- [x] fwlib30i.dll
- [x] All other FOCAS DLLs
- [x] All .NET runtime DLLs (api-ms-win-*, System.*, Microsoft.*)

Total: ~270 files, ~75 MB

---

## Next Steps

1. ✅ Build and test on main PC
2. ⬜ Deploy to collector PC
3. ⬜ Verify data collection for 24 hours
4. ⬜ Build utilization reports
5. ⬜ Create dashboard
6. ⬜ Integrate with ProShop

---

## Collector PC Info

- **Location:** Shop floor
- **OS:** Windows 10 Pro
- **IP:** On 10.1.1.x network
- **User:** WrkStationC
- **.NET:** Runtime 6.0.8 installed (self-contained build doesn't need it)
