# FocasMonitor — Extended

Full FOCAS data collection for all 0i-MF machines. Drop-in replacement for original FocasMonitor.

## What's New

### New data collected every poll (60s):
- **System info**: CNC type, series, software version, unique hardware ID
- **Active block content**: The G-code line currently executing
- **CAPTURE tags**: Auto-parsed from block comments — SESSION, OP_ID, TOOL_ID
- **Spindle load %**: 0-200 (100 = rated load)
- **Current tool number**: T number in spindle
- **Machine coordinates**: Position from machine zero (vs workpiece zero)
- **Distance to go**: Remaining distance in current move
- **Servo loads**: Per-axis motor load %
- **Machine life counters**: Total power-on time, cutting time, cycle time (minutes)
- **Tool life config**: Whether enabled and type (time/count)
- **Extended status**: Warning field

### New data collected when machine is running:
- **Tool wear registers**: All H and D offset values (length + diameter wear and geometry)
- **Tool life data**: Per-group and per-tool life used/remaining (when tool life enabled)

### New data collected every poll, logged only on change:
- **Work coordinate offsets**: G54-G59 values — logs when operator changes them

### New data collected every 10 polls (~10 min):
- **Parameter snapshots**: Key parameters including tool life config block (6800-6819)
- **Program directory**: List of all programs in controller memory with comments

## New Database Tables

| Table | Purpose |
|-------|---------|
| `machine_samples` | Extended — many new columns |
| `tool_wear_samples` | H/D register values per tool per session |
| `tool_life_samples` | Tool life used/remaining (when TLM enabled) |
| `wco_samples` | Work coordinate offsets, change-detected |
| `parameter_snapshots` | Key parameter values over time |
| `alarm_history` | Full alarm log with session correlation |
| `program_directory` | Programs loaded in each machine |

## CAPTURE Tag Correlation

When NC programs contain CAPTURE comment tags, they are automatically
correlated to programming sessions from the Fusion diff engine:

```gcode
(CAPTURE:SESSION=2026-03-03_abc123)
(CAPTURE:OP_ID=adaptive2d_001)
(CAPTURE:TOOL_ID=1-2FL-EM)
```

These populate `capture_session_id`, `capture_op_id`, `capture_tool_id`
in `machine_samples` and `tool_wear_samples`, enabling direct join between
machine performance and the programming decisions that produced the program.

## Installation

Same as original — replace the three source files, rebuild, reinstall service.

The database schema is additive. If upgrading from the original version,
the new tables will be created automatically. The original `machine_samples`
columns are preserved; new columns are added. Existing data is untouched.

**Note:** The original `machine_samples` table will NOT have the new columns
added automatically on upgrade — the new columns only apply to fresh databases.
For an in-place upgrade, run the ALTER TABLE statements in `migrate.sql`.

## Upgrade Migration

If upgrading from original FocasMonitor, run `migrate.sql` against the existing
monitoring.db before starting the new service.
