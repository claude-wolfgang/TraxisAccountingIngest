using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace FocasMonitor;

public class MonitoringService : BackgroundService
{
    private readonly ILogger<MonitoringService> _logger;
    private readonly Config _config;
    private readonly Database _db;

    // Track previous alarm state per machine to detect new alarms
    private readonly Dictionary<string, int> _lastAlarmState = new();

    // Track previous WCO values per machine to detect changes
    private readonly Dictionary<string, Dictionary<int, int[]>> _lastWcoValues = new();

    // Slow poll counter — some data doesn't need every 60s
    private int _pollCount = 0;

    // Key parameters to snapshot (number → description)
    private static readonly Dictionary<short, string> ParametersToCapture = new()
    {
        { 6800, "Tool life management enable/config" },
        { 6801, "Tool life type (0=count, 1=time)" },
        { 6813, "Max tool groups (0i-MF)" },
        { 1020, "Axis name assignment" },
        { 1022, "Axis type (linear/rotary)" },
        { 1401, "Feed clamp / override config" },
        { 1422, "Max cutting feedrate" },
        { 3111, "Display options" },
    };

    public MonitoringService(ILogger<MonitoringService> logger)
    {
        _logger = logger;
        _config = LoadConfig();
        _db = new Database(_config.DatabasePath);
    }

    private static Config LoadConfig()
    {
        var configPath = Path.Combine(AppContext.BaseDirectory, "machines.json");
        if (!File.Exists(configPath))
            throw new FileNotFoundException($"Configuration file not found: {configPath}");
        var json = File.ReadAllText(configPath);
        return JsonSerializer.Deserialize<Config>(json) ?? throw new Exception("Failed to parse config");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("FOCAS Monitoring Service started (extended)");
        _logger.LogInformation("Database: {Path}", _config.DatabasePath);
        _logger.LogInformation("Poll interval: {Interval}s", _config.PollIntervalSeconds);
        _logger.LogInformation("Machines enabled: {Count}", _config.Machines.Count(m => m.Enabled));

        // Initialize WCO tracking from DB
        foreach (var machine in _config.Machines.Where(m => m.Enabled))
            _lastWcoValues[machine.Id] = _db.GetLastWcoValues(machine.Id);

        while (!stoppingToken.IsCancellationRequested)
        {
            var pollStart = DateTime.Now;
            _pollCount++;

            foreach (var machine in _config.Machines.Where(m => m.Enabled && !string.IsNullOrEmpty(m.Ip)))
            {
                try
                {
                    PollMachine(machine);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Unhandled error polling {Id}", machine.Id);
                    _db.InsertSample(new MachineSample
                    {
                        Timestamp = DateTime.Now,
                        MachineId = machine.Id,
                        MachineName = machine.Name,
                        Connected = false,
                        ErrorMessage = ex.Message
                    });
                }
            }

            var elapsed = DateTime.Now - pollStart;
            _logger.LogInformation("Poll #{Count} complete in {Ms}ms", _pollCount, (int)elapsed.TotalMilliseconds);

            var delay = TimeSpan.FromSeconds(_config.PollIntervalSeconds) - elapsed;
            if (delay > TimeSpan.Zero)
                await Task.Delay(delay, stoppingToken);
        }
    }

    private void PollMachine(MachineConfig machine)
    {
        var sample = new MachineSample
        {
            Timestamp = DateTime.Now,
            MachineId = machine.Id,
            MachineName = machine.Name
        };

        ushort handle = 0;
        try
        {
            // Connect
            short ret = Focas.cnc_allclibhndl3(machine.Ip, (ushort)machine.Port, 3, out handle);
            if (ret != 0)
            {
                sample.Connected = false;
                sample.ErrorMessage = $"Connection failed (error {ret})";
                _db.InsertSample(sample);
                return;
            }
            sample.Connected = true;

            // ----------------------------------------------------------------
            // SYSTEM INFO  (every poll — cheap, useful for drift detection)
            // ----------------------------------------------------------------
            if (Focas.cnc_sysinfo(handle, out var sysinfo) == 0)
            {
                sample.CncType  = sysinfo.cnc_type?.Trim();
                sample.MtType   = sysinfo.mt_type?.Trim();
                sample.Series   = sysinfo.series?.Trim();
                sample.SwVersion= sysinfo.version?.Trim();
                sample.MaxAxes  = sysinfo.max_axis;
            }

            // CNC hardware ID (unique per controller board)
            var cncid = new uint[4];
            if (Focas.cnc_rdcncid(handle, cncid) == 0)
                sample.CncId = string.Join("-", cncid.Select(x => x.ToString("X8")));

            // ----------------------------------------------------------------
            // STATUS
            // ----------------------------------------------------------------
            if (Focas.cnc_statinfo(handle, out var status) == 0)
            {
                sample.Mode       = Focas.GetModeString(status.aut);
                sample.RunStatus  = Focas.GetRunStatusString(status.run);
                sample.Motion     = Focas.GetMotionString(status.motion);
                sample.EditStatus = status.edit;
                sample.Emergency  = status.emergency;
                sample.Alarm      = status.alarm;
            }

            // Extended status (warning field)
            if (Focas.cnc_statinfo2(handle, out var status2) == 0)
                sample.Warning = status2.warning;

            // ----------------------------------------------------------------
            // PROGRAM
            // ----------------------------------------------------------------
            if (Focas.cnc_rdprgnum(handle, out var prgnum) == 0)
            {
                sample.ProgramNumber = prgnum.data;
                sample.MainProgram   = prgnum.mdata;
            }

            if (Focas.cnc_rdseqnum(handle, out var seqnum) == 0)
                sample.SequenceNumber = seqnum.data;

            if (Focas.cnc_rdblkcount(handle, out int blkcount) == 0)
                sample.BlockCount = blkcount;

            // ----------------------------------------------------------------
            // ACTIVE BLOCK — capture tag parsing
            // ----------------------------------------------------------------
            var blockContent = Focas.ReadActiveBlockComment(handle);
            if (blockContent != null)
            {
                sample.ActiveBlockContent = blockContent;
                var tags = Focas.ParseCaptureTags(blockContent);
                if (tags != null)
                {
                    tags.TryGetValue("SESSION",  out var sessionId);
                    tags.TryGetValue("OP_ID",    out var opId);
                    tags.TryGetValue("TOOL_ID",  out var toolId);
                    sample.CaptureSessionId = sessionId;
                    sample.CaptureOpId      = opId;
                    sample.CaptureToolId    = toolId;
                }
            }

            // ----------------------------------------------------------------
            // SPEEDS AND OVERRIDES
            // ----------------------------------------------------------------
            if (Focas.cnc_rdspeed(handle, -1, out var speed) == 0)
            {
                sample.SpindleSpeed = speed.acts.data;
                sample.FeedRate     = speed.actf.data;
            }

            if (Focas.cnc_rdfeedoveride(handle, 0, out short feedOvr) == 0)
                sample.FeedrateOverride = feedOvr;

            if (Focas.cnc_rdspindleid(handle, 0, out short spindleOvr) == 0)
                sample.SpindleOverride = spindleOvr;

            // Spindle load %
            if (Focas.cnc_rdspload(handle, 0, out var spload) == 0)
                sample.SpindleLoad = spload.spload;

            // ----------------------------------------------------------------
            // CURRENT TOOL
            // ----------------------------------------------------------------
            if (Focas.cnc_rdtool(handle, out var tool) == 0)
                sample.ToolNumber = tool.tool_no;

            // ----------------------------------------------------------------
            // MODAL G-CODES — active WCS
            // ----------------------------------------------------------------
            // Note: modal read is complex, use a simplified approach
            // G54=1, G55=2... stored in modal group 14
            // We'll derive from work offset in use if modal fails
            // This is best-effort — null if unavailable
            // (Full modal struct requires careful size calculation per machine)

            // ----------------------------------------------------------------
            // AXIS POSITIONS
            // ----------------------------------------------------------------
            // Absolute
            if (Focas.cnc_absolute2(handle, -1, (short)(4 + 8 * 5), out var absPos) == 0
                && absPos.data != null)
            {
                if (absPos.data.Length > 0) sample.AxisX = absPos.data[0];
                if (absPos.data.Length > 1) sample.AxisY = absPos.data[1];
                if (absPos.data.Length > 2) sample.AxisZ = absPos.data[2];
                if (absPos.data.Length > 3) sample.AxisA = absPos.data[3];
                if (absPos.data.Length > 4) sample.AxisB = absPos.data[4];
            }

            // Machine coordinates
            if (Focas.cnc_machine2(handle, -1, (short)(4 + 8 * 3), out var machPos) == 0
                && machPos.data != null)
            {
                if (machPos.data.Length > 0) sample.MachX = machPos.data[0];
                if (machPos.data.Length > 1) sample.MachY = machPos.data[1];
                if (machPos.data.Length > 2) sample.MachZ = machPos.data[2];
            }

            // Distance to go
            if (Focas.cnc_distance2(handle, -1, (short)(4 + 8 * 3), out var dtgPos) == 0
                && dtgPos.data != null)
            {
                if (dtgPos.data.Length > 0) sample.DtgX = dtgPos.data[0];
                if (dtgPos.data.Length > 1) sample.DtgY = dtgPos.data[1];
                if (dtgPos.data.Length > 2) sample.DtgZ = dtgPos.data[2];
            }

            // ----------------------------------------------------------------
            // SERVO LOADS
            // ----------------------------------------------------------------
            short axisCount = 4;
            var svloads = new Focas.ODBSVLOAD[4];
            if (Focas.cnc_rdsvmeter(handle, ref axisCount, svloads) == 0)
            {
                if (axisCount > 0) sample.ServoLoadX = svloads[0].svload;
                if (axisCount > 1) sample.ServoLoadY = svloads[1].svload;
                if (axisCount > 2) sample.ServoLoadZ = svloads[2].svload;
                if (axisCount > 3) sample.ServoLoadA = svloads[3].svload;
            }

            // ----------------------------------------------------------------
            // ALARMS — log new ones to alarm_history
            // ----------------------------------------------------------------
            if (Focas.cnc_alarm(handle, out var alm) == 0)
            {
                sample.Alarm = alm.data;

                if (alm.data != 0)
                {
                    short almCount = 10;
                    var almMsgs = new Focas.ODBALMMSG[10];
                    if (Focas.cnc_rdalmmsg(handle, -1, ref almCount, almMsgs) == 0 && almCount > 0)
                    {
                        sample.AlarmMessage = almMsgs[0].alm_msg?.Trim();

                        // Log each new alarm to history
                        foreach (var msg in almMsgs.Take(almCount))
                        {
                            if (!_db.AlarmAlreadyRecorded(machine.Id, msg.alm_no,
                                    DateTime.Now.AddMinutes(-5)))
                            {
                                _db.InsertAlarmHistory(new AlarmHistorySample
                                {
                                    Timestamp        = sample.Timestamp,
                                    MachineId        = machine.Id,
                                    AlarmNumber      = msg.alm_no,
                                    AlarmType        = msg.type,
                                    AlarmAxis        = msg.axis,
                                    AlarmMessage     = msg.alm_msg?.Trim(),
                                    CaptureSessionId = sample.CaptureSessionId,
                                    CaptureOpId      = sample.CaptureOpId,
                                    ProgramNumber    = sample.ProgramNumber
                                });
                                _logger.LogWarning("{Id}: ALARM {No} — {Msg}",
                                    machine.Id, msg.alm_no, msg.alm_msg?.Trim());
                            }
                        }
                    }
                }
            }

            // ----------------------------------------------------------------
            // DIAGNOSIS COUNTERS (machine life data)
            // ----------------------------------------------------------------
            sample.DiagPowerOnMin = Focas.ReadDiagnosis(handle, 300);
            sample.DiagCuttingMin = Focas.ReadDiagnosis(handle, 301);
            sample.DiagCycleMin   = Focas.ReadDiagnosis(handle, 302);

            // ----------------------------------------------------------------
            // TOOL LIFE MANAGEMENT CONFIG
            // ----------------------------------------------------------------
            var p6800 = Focas.ReadParameter(handle, 6800);
            if (p6800.HasValue)
            {
                sample.ToolLifeEnabled = p6800.Value & 0x01;
                sample.ToolLifeType    = (p6800.Value & 0x02) != 0 ? "time" : "count";
            }

            // Write main sample
            _db.InsertSample(sample);

            // ----------------------------------------------------------------
            // TOOL WEAR REGISTERS — every poll when machine is running
            // ----------------------------------------------------------------
            if (sample.RunStatus == "STRT" || sample.RunStatus == "MSTR")
            {
                ReadToolWearRegisters(handle, machine.Id,
                    sample.CaptureSessionId, sample.CaptureOpId, sample.ToolNumber);
            }

            // ----------------------------------------------------------------
            // TOOL LIFE DATA — every poll if enabled
            // ----------------------------------------------------------------
            if (sample.ToolLifeEnabled == 1)
            {
                ReadToolLifeData(handle, machine.Id, sample.ToolLifeType ?? "count");
            }

            // ----------------------------------------------------------------
            // WORK COORDINATE OFFSETS — every poll, log only on change
            // ----------------------------------------------------------------
            ReadWorkCoordinates(handle, machine.Id);

            // ----------------------------------------------------------------
            // SLOW POLLS — every 10 cycles (~10 minutes at 60s interval)
            // ----------------------------------------------------------------
            if (_pollCount % 10 == 1)
            {
                ReadParameters(handle, machine.Id);
                ReadProgramDirectory(handle, machine.Id);
            }

            _logger.LogDebug("{Id}: {Status} | T{Tool} | S{RPM}rpm | F{Feed} | Load{Load}% | Prog O{Prog}",
                machine.Id, sample.RunStatus, sample.ToolNumber, sample.SpindleSpeed,
                sample.FeedRate, sample.SpindleLoad, sample.ProgramNumber);
        }
        finally
        {
            if (handle != 0)
                Focas.cnc_freelibhndl(handle);
        }
    }

    // ----------------------------------------------------------------
    // TOOL WEAR REGISTERS
    // ----------------------------------------------------------------
    private void ReadToolWearRegisters(ushort handle, string machineId,
        string? sessionId, string? opId, int? currentTool)
    {
        try
        {
            if (Focas.cnc_rdtofsinfo(handle, out var info) != 0) return;

            short count = (short)Math.Min(info.use_no, 64);
            var tofs = new Focas.ODBTOFS[count];

            // type: 0=geometry+wear length, 1=geometry+wear diameter
            // Read all offsets — type -1 or iterate
            if (Focas.cnc_rdtofs(handle, 1, count, 0, tofs) == 0)
            {
                var ts = DateTime.Now;
                foreach (var tof in tofs.Take(count))
                {
                    _db.InsertToolWearSample(new ToolWearSample
                    {
                        Timestamp        = ts,
                        MachineId        = machineId,
                        CaptureSessionId = sessionId,
                        CaptureOpId      = opId,
                        ToolNumber       = currentTool,
                        OffsetNumber     = tof.number,
                        LengthWear       = tof.data?.Length > 0 ? tof.data[0] : null,
                        DiameterWear     = tof.data?.Length > 1 ? tof.data[1] : null,
                        LengthGeometry   = tof.data?.Length > 2 ? tof.data[2] : null,
                        DiameterGeometry = tof.data?.Length > 3 ? tof.data[3] : null,
                    });
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug("Tool wear read failed for {Id}: {Ex}", machineId, ex.Message);
        }
    }

    // ----------------------------------------------------------------
    // TOOL LIFE DATA
    // ----------------------------------------------------------------
    private void ReadToolLifeData(ushort handle, string machineId, string lifeType)
    {
        try
        {
            if (Focas.cnc_rdtlinfo(handle, out var tlinfo) != 0) return;

            var ts = DateTime.Now;
            for (short grp = 1; grp <= tlinfo.use_grp; grp++)
            {
                if (Focas.cnc_rdtlife(handle, grp, out var tlife) != 0) continue;

                double remainingPct = tlife.life > 0
                    ? Math.Round(100.0 * (tlife.life - tlife.count) / tlife.life, 1)
                    : 0;

                // Read individual tools in group
                for (short t = 0; t < tlinfo.max_tool; t++)
                {
                    if (Focas.cnc_rdtlifd(handle, grp, t, out var tlifd) != 0) continue;
                    if (tlifd.tool_no == 0) continue; // empty slot

                    _db.InsertToolLifeSample(new ToolLifeSample
                    {
                        Timestamp        = ts,
                        MachineId        = machineId,
                        GroupNumber      = grp,
                        ToolNumber       = tlifd.tool_no,
                        HOffset          = tlifd.h_code,
                        DOffset          = tlifd.d_code,
                        LifeLimit        = tlife.life,
                        LifeUsed         = tlife.count,
                        LifeRemainingPct = remainingPct,
                        LifeType         = lifeType,
                        Status           = tlifd.status switch
                        {
                            0 => "available",
                            1 => "used",
                            2 => "expired",
                            _ => $"unknown({tlifd.status})"
                        }
                    });
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug("Tool life read failed for {Id}: {Ex}", machineId, ex.Message);
        }
    }

    // ----------------------------------------------------------------
    // WORK COORDINATE OFFSETS
    // ----------------------------------------------------------------
    private void ReadWorkCoordinates(ushort handle, string machineId)
    {
        try
        {
            var ts = DateTime.Now;
            var wcoData = new Focas.ODBWKOFS[6];

            if (Focas.cnc_rdwkcofs(handle, 0, 1, 6, wcoData) != 0) return;

            if (!_lastWcoValues.ContainsKey(machineId))
                _lastWcoValues[machineId] = new Dictionary<int, int[]>();

            var wcsNames = new[] { "", "G54", "G55", "G56", "G57", "G58", "G59" };

            for (int i = 0; i < 6; i++)
            {
                var wco = wcoData[i];
                int wcsNum = i + 1;
                var current = new[] {
                    wco.data?.Length > 0 ? wco.data[0] : 0,
                    wco.data?.Length > 1 ? wco.data[1] : 0,
                    wco.data?.Length > 2 ? wco.data[2] : 0,
                    wco.data?.Length > 3 ? wco.data[3] : 0,
                };

                bool changed = !_lastWcoValues[machineId].TryGetValue(wcsNum, out var prev)
                    || !current.SequenceEqual(prev);

                // Always write on change; write every 10 polls even if unchanged (heartbeat)
                if (changed || _pollCount % 10 == 1)
                {
                    _db.InsertWcoSample(new WcoSample
                    {
                        Timestamp = ts,
                        MachineId = machineId,
                        WcsNumber = wcsNum,
                        WcsName   = wcsNames[wcsNum],
                        OffsetX   = current[0],
                        OffsetY   = current[1],
                        OffsetZ   = current[2],
                        OffsetA   = current[3],
                        Changed   = changed
                    });

                    if (changed)
                    {
                        _logger.LogInformation("{Id}: WCO {WCS} changed", machineId, wcsNames[wcsNum]);
                        _lastWcoValues[machineId][wcsNum] = current;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug("WCO read failed for {Id}: {Ex}", machineId, ex.Message);
        }
    }

    // ----------------------------------------------------------------
    // PARAMETERS (slow poll)
    // ----------------------------------------------------------------
    private void ReadParameters(ushort handle, string machineId)
    {
        try
        {
            var ts = DateTime.Now;
            foreach (var (paramNum, description) in ParametersToCapture)
            {
                var value = Focas.ReadParameter(handle, paramNum);
                if (value.HasValue)
                {
                    _db.InsertParameterSnapshot(new ParameterSnapshot
                    {
                        Timestamp   = ts,
                        MachineId   = machineId,
                        ParamNumber = paramNum,
                        Axis        = 0,
                        Value       = value,
                        Description = description
                    });
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug("Parameter read failed for {Id}: {Ex}", machineId, ex.Message);
        }
    }

    // ----------------------------------------------------------------
    // PROGRAM DIRECTORY (slow poll)
    // ----------------------------------------------------------------
    private void ReadProgramDirectory(ushort handle, string machineId)
    {
        try
        {
            short count = 100;
            var dir = new Focas.PRGDIR2[100];
            if (Focas.cnc_rdprogdir2(handle, 0, ref count, dir) == 0 && count > 0)
            {
                _db.InsertProgramDirectory(machineId, dir, count);
                _logger.LogDebug("{Id}: {Count} programs in memory", machineId, count);
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug("Program directory read failed for {Id}: {Ex}", machineId, ex.Message);
        }
    }
}

// Configuration classes (unchanged from original)
public class Config
{
    public int PollIntervalSeconds { get; set; } = 60;
    public string DatabasePath { get; set; } = @"C:\FASData\monitoring.db";
    public string LogPath { get; set; } = @"C:\FASData\logs";
    public List<MachineConfig> Machines { get; set; } = new();
}

public class MachineConfig
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";
    public string Ip { get; set; } = "";
    public int Port { get; set; } = 8193;
    public bool Enabled { get; set; } = true;
    public string? Notes { get; set; }
}
