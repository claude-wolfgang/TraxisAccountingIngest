# ProShop Conversational Interface — Claude Code Project

**Created:** January 26, 2026  
**Purpose:** Build a natural language interface for querying ProShop ERP  
**Approach:** Read-only queries to start, validate feasibility before full implementation

---

## Project Overview

Build a conversational interface that lets Traxis Manufacturing employees query ProShop ERP using natural language instead of clicking through the web UI.

**Example queries:**
- "What's the status of WO 25-0001?"
- "Show me all open jobs for R2Sonic"
- "What parts are due this week?"
- "What operations are on part TRA1-TEMP?"

**End goal:** A CLI or chat interface that takes plain English → translates to GraphQL → executes against ProShop API → returns readable results.

---

## Company Context

**Traxis Manufacturing** — 5-person precision CNC shop in Austin, TX  
- ~20 active customers, ~20 monthly orders  
- Largest customer: R2Sonic (multibeam sonar systems)  
- Uses ProShop ERP for work orders, scheduling, process documentation

**Existing ProShop API Integration:**
- OAuth 2.0 authentication working
- GraphQL queries and mutations working
- Fusion 360 → ProShop automation already built

---

## Technical Context

### ProShop API Details

| Item | Value |
|------|-------|
| Base URL | `https://traxismfg.adionsystems.com` |
| GraphQL Endpoint | `https://traxismfg.adionsystems.com/api/graphql` |
| Auth Endpoint | `/home/member/oauth/accesstoken` |
| Auth Method | OAuth 2.0 Client Credentials |
| Client ID | `3923-9C1C-7291` |
| Scope | `parts:rwdp+workorders:rwdp` |
| Token Lifetime | 86400 seconds (24 hours) |

### Authentication Flow

```
POST /home/member/oauth/accesstoken
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id=3923-9C1C-7291&client_secret=[SECRET]&scope=parts:rwdp+workorders:rwdp
```

Response:
```json
{
  "access_token": "...",
  "token_type": "Bearer",
  "expires_in": 86400
}
```

Use: `Authorization: Bearer [access_token]` header on all GraphQL requests.

### Known Working Queries

**Get part with operations:**
```graphql
query GetPart($partNumber: [String!]!) {
  parts(filter: { partNumber: $partNumber }) {
    records {
      partNumber
      partDescription
      operations {
        records {
          opNumber
          operationDescription
          writtenDescriptions {
            records {
              legacyId
              writtenDescription
            }
          }
          tools {
            records {
              sequenceNumber
              outOfHolder
              holder
              sequenceDescription
            }
          }
        }
      }
    }
  }
}
```

**Get work order with operations:**
```graphql
{
  workOrder(workOrderNumber: "25-0001") {
    ops {
      records {
        operationNumber
        partOperation {
          writtenDescriptions {
            records {
              legacyId
              writtenDescription
            }
          }
        }
      }
    }
  }
}
```

### Known API Issues

1. **Parts filter seems broken** — Sometimes returns empty for known part numbers
2. **Written Description display bug** — Data written via API doesn't display in UI (legacyId issue)
3. **Work order nested filter by PO doesn't work** — Must fetch all and match client-side

---

## Existing Code Reference

The existing ProShop GraphQL client is in the `reference_code/` directory. Key class:

```python
class ProShopGraphQL:
    def __init__(self, base_url=PROSHOP_BASE_URL):
        self.base_url = f"{base_url}/api/graphql"
        self.base_root = base_url
        self.session = requests.Session()
        self.authenticated = False
        self.access_token = None
    
    def authenticate_oauth(self, client_id, client_secret):
        # OAuth 2.0 Client Credentials flow
        # Returns True/False
        
    def execute(self, query, variables=None):
        # Execute GraphQL query
        # Returns data dict or raises Exception
```

---

## Phase 0: Feasibility Spike (RUN THIS FIRST)

Before building anything, validate that this project is viable. Run these tests in sequence and log all results.

### Test 1: Schema Discovery

**Question:** What can we actually query via GraphQL?

**Steps:**
1. Authenticate with OAuth
2. Run GraphQL introspection query:
```graphql
{
  __schema {
    queryType {
      fields {
        name
        description
        args {
          name
          type { name kind }
        }
        type {
          name
          kind
          ofType { name kind }
        }
      }
    }
  }
}
```
3. Log all available query types to `results/01_schema_discovery.json`
4. Check for these key entities: workOrder, workOrders, parts, customers, jobs, contacts

**Pass criteria:** Core entities (workOrder, parts) are queryable  
**Time box:** 1 hour

---

### Test 2: Single-Query Usefulness

**Question:** Can we answer useful questions with single queries?

**Steps:**
1. Query a known work order (try "25-0001" or similar recent WO)
2. Query a known part number
3. For each, document what fields are returned
4. Determine if we can get: status, customer info, due date, operations in one query

**Log to:** `results/02_query_usefulness.md`

**Pass criteria:** At least 5 common questions answerable with single query  
**Time box:** 1-2 hours

---

### Test 3: Auth Reliability

**Question:** Does OAuth hold up under repeated use?

**Steps:**
1. Authenticate once
2. Make 20 queries in a row (simple queries, don't need to vary)
3. Check all succeed
4. Note any failures or token issues

**Log to:** `results/03_auth_reliability.md`

**Pass criteria:** No manual intervention needed for auth during session  
**Time box:** 30 minutes

---

### Test 4: Rate Limits

**Question:** Will ProShop throttle us?

**Steps:**
1. Fire 10 queries as fast as possible (burst)
2. Check for 429 errors or degraded responses
3. Examine response headers for rate limit info
4. Document any throttling behavior

**Log to:** `results/04_rate_limits.md`

**Pass criteria:** Can sustain conversational pace (1 query/few seconds)  
**Time box:** 30 minutes

---

### Test 5: Query Coverage Mapping

**Question:** What queries would we actually need?

**Steps:**
1. List 20 example questions someone might ask (see below)
2. For each, determine: what GraphQL query would answer it?
3. Categorize: Easy (single query), Complex (chained), Impossible (not in API)

**Example questions to map:**
1. What's the status of WO 25-0001?
2. Show me all open work orders
3. What work orders are due this week?
4. What operations are on part XYZ?
5. Who is the contact for customer ABC?
6. What's the current operation for WO 25-0001?
7. Show me R2Sonic's open orders
8. What tools are needed for Op 60 on part XYZ?
9. When is WO 25-0001 due?
10. How many open work orders do we have?
11. What work orders were shipped last week?
12. Show me all parts for customer R2Sonic
13. What's the job number for WO 25-0001?
14. Are there any late work orders?
15. What operations need to be run today?
16. Show me the sequence details for part XYZ Op 60
17. What's the priority of WO 25-0001?
18. Who is assigned to WO 25-0001?
19. What's the quantity for WO 25-0001?
20. Show me all work orders in "In Process" status

**Log to:** `results/05_query_coverage.md`

**Pass criteria:** 80%+ of questions are answerable (easy + complex)  
**Time box:** 1 hour

---

### Feasibility Decision

After Tests 1-5, write a `results/00_GO_NO_GO.md` file with:

1. **Schema coverage:** What percentage of desired queries are possible?
2. **Query complexity:** How many require chaining vs single query?
3. **Auth stability:** Any issues?
4. **Rate limiting:** Any concerns?
5. **Recommendation:** GO / NO-GO / GO WITH CAVEATS

**Decision matrix:**
- If schema is too limited → STOP (no API support for needed queries)
- If >50% queries need complex chaining → CONSIDER simplifying scope
- If auth/rate limits are problems → INVESTIGATE workarounds first
- If 80%+ queries are feasible → GO

---

## Phase 1: Foundation (Only if Phase 0 = GO)

### Task 1.1: Create Query Template Library

Based on schema discovery, create `src/query_templates.py`:

```python
QUERY_TEMPLATES = {
    "work_order_status": {
        "description": "Get status of a work order",
        "query": """...""",
        "variables": ["workOrderNumber"],
        "extract": lambda data: data["workOrder"]["status"]
    },
    # ... more templates
}
```

### Task 1.2: Build Intent Classifier

Create `src/intent_classifier.py`:

- Map natural language patterns to query template names
- Extract parameters (WO numbers, part numbers, dates, customer names)
- Handle ambiguous queries (return clarification needed)

### Task 1.3: Build Response Formatter

Create `src/response_formatter.py`:

- Convert raw GraphQL JSON to readable text
- Format tables for list queries
- Handle empty results gracefully

---

## Phase 2: Interface (Only if Phase 1 complete)

### Task 2.1: CLI Chat Loop

Create `src/cli.py`:

```python
def main():
    api = ProShopGraphQL()
    api.authenticate_oauth(client_id, client_secret)
    
    print("ProShop Assistant ready. Type 'help' for examples, 'quit' to exit.")
    
    while True:
        user_input = input("\nYou: ").strip()
        if user_input.lower() == 'quit':
            break
        
        response = process_query(api, user_input)
        print(f"\n{response}")
```

### Task 2.2: Help System

- Show example queries
- Show available query types
- "raw" mode to see actual GraphQL being sent

---

## Phase 3: Polish (Only if Phase 2 complete)

- Handle follow-up questions ("what about that customer's other jobs?")
- Add query history/context
- Improve error messages
- Add more query templates based on usage

---

## File Structure

```
proshop_conversational_interface/
├── PROJECT.md                    # This file
├── CREDENTIALS.md                # Where to put secrets (gitignored)
├── reference_code/               # Existing ProShop API code for reference
│   ├── proshop_graphql_v2.py
│   └── PROJECT_STATE.md
├── results/                      # Feasibility test results
│   ├── 00_GO_NO_GO.md
│   ├── 01_schema_discovery.json
│   ├── 02_query_usefulness.md
│   ├── 03_auth_reliability.md
│   ├── 04_rate_limits.md
│   └── 05_query_coverage.md
├── src/                          # Implementation (Phase 1+)
│   ├── proshop_client.py        # OAuth + GraphQL client
│   ├── query_templates.py       # Parameterized queries
│   ├── intent_classifier.py     # NL → query mapping
│   ├── response_formatter.py    # JSON → readable text
│   └── cli.py                   # Main interface
└── tests/                        # Unit tests
```

---

## Credentials Setup

Create a `CREDENTIALS.md` file (will be gitignored) with:

```markdown
# ProShop API Credentials

CLIENT_ID=3923-9C1C-7291
CLIENT_SECRET=[ask Wolfgang]

# For Selenium workaround (if needed later)
PROSHOP_USERNAME=tbuerkle
PROSHOP_PASSWORD=[ask Wolfgang]
```

Or set as environment variables:
```bash
export PROSHOP_CLIENT_ID="3923-9C1C-7291"
export PROSHOP_CLIENT_SECRET="..."
```

---

## Claude Code Instructions

### Starting the Project

1. Read this entire PROJECT.md first
2. Check if credentials are available (env vars or CREDENTIALS.md)
3. If no credentials, create CREDENTIALS.md template and STOP with message asking for secrets

### Running Feasibility Spike

1. Run Tests 1-5 in order
2. Log all results to `results/` directory
3. Write `00_GO_NO_GO.md` with recommendation
4. If NO-GO, explain why and STOP
5. If GO, proceed to Phase 1

### Implementation

1. Only proceed to Phase 1 if feasibility = GO
2. Build incrementally, test each component
3. Log progress to `results/progress.md`
4. If blocked, document blocker and STOP

### Error Handling

- If auth fails: Log error, check credentials, retry once, then STOP
- If API unreachable: Log error, STOP
- If rate limited: Log error, wait 60 seconds, retry, then STOP if still limited
- If schema introspection fails: Try alternative query, log results

### Output Expectations

After overnight run, should have:
- `results/` folder with all test results
- `00_GO_NO_GO.md` with clear recommendation
- If GO: Initial `src/` files with working client
- `progress.md` with what was accomplished and any blockers

---

## Notes

- This is READ-ONLY to start — no mutations, no risk of corrupting data
- ProShop API costs $3,630/year — already paying for it, might as well use it
- Long-term could expand to: work order creation, status updates, mobile interface
- Written Description bug only affects writes — reads should work fine
