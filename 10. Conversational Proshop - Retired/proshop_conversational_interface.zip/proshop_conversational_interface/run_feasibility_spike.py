#!/usr/bin/env python3
"""
ProShop Conversational Interface - Feasibility Spike
Run all tests and generate go/no-go recommendation.

Usage:
    python run_feasibility_spike.py

Requires environment variables:
    PROSHOP_CLIENT_ID (default: 3923-9C1C-7291)
    PROSHOP_CLIENT_SECRET (required)
"""

import os
import sys
import json
import time
import requests
from datetime import datetime
from pathlib import Path

# Configuration
PROSHOP_BASE_URL = "https://traxismfg.adionsystems.com"
RESULTS_DIR = Path(__file__).parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

# Default client ID
DEFAULT_CLIENT_ID = "3923-9C1C-7291"


class ProShopClient:
    """Minimal ProShop GraphQL client for testing."""
    
    def __init__(self, base_url=PROSHOP_BASE_URL):
        self.base_url = f"{base_url}/api/graphql"
        self.base_root = base_url
        self.session = requests.Session()
        self.access_token = None
    
    def authenticate(self, client_id, client_secret):
        """OAuth 2.0 Client Credentials authentication."""
        endpoint = f"{self.base_root}/home/member/oauth/accesstoken"
        scope = "parts:rwdp+workorders:rwdp"
        body = f"grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&scope={scope}"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        
        response = requests.post(endpoint, data=body, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("access_token"):
                self.access_token = data["access_token"]
                self.session.headers.update({
                    "Authorization": f"Bearer {self.access_token}",
                    "Content-Type": "application/json"
                })
                return True, f"Token valid for {data.get('expires_in', 0) // 3600} hours"
        
        return False, f"Auth failed: {response.status_code} - {response.text}"
    
    def execute(self, query, variables=None):
        """Execute GraphQL query. Returns (success, data_or_error)."""
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        
        response = self.session.post(self.base_url, json=payload)
        
        if response.status_code != 200:
            return False, f"HTTP {response.status_code}: {response.text}"
        
        result = response.json()
        if "errors" in result:
            return False, result["errors"]
        
        return True, result.get("data", {})


def log_result(filename, content):
    """Write content to results file."""
    filepath = RESULTS_DIR / filename
    with open(filepath, "w") as f:
        if isinstance(content, (dict, list)):
            json.dump(content, f, indent=2)
        else:
            f.write(content)
    print(f"  → Logged to {filepath}")


def test_1_schema_discovery(client):
    """Test 1: Discover available GraphQL schema."""
    print("\n" + "="*60)
    print("TEST 1: Schema Discovery")
    print("="*60)
    
    introspection_query = """
    {
      __schema {
        queryType {
          fields {
            name
            description
            args {
              name
              type { name kind }
            }
            type {
              name
              kind
              ofType { name kind }
            }
          }
        }
      }
    }
    """
    
    success, data = client.execute(introspection_query)
    
    if not success:
        print(f"  ✗ Introspection failed: {data}")
        log_result("01_schema_discovery.json", {"success": False, "error": str(data)})
        return False
    
    fields = data.get("__schema", {}).get("queryType", {}).get("fields", [])
    print(f"  ✓ Found {len(fields)} query types")
    
    # Check for key entities
    field_names = [f["name"] for f in fields]
    key_entities = ["workOrder", "workOrders", "parts", "customers", "contacts", "jobs"]
    found = [e for e in key_entities if e in field_names]
    missing = [e for e in key_entities if e not in field_names]
    
    print(f"  Key entities found: {found}")
    if missing:
        print(f"  Key entities MISSING: {missing}")
    
    log_result("01_schema_discovery.json", {
        "success": True,
        "query_count": len(fields),
        "query_names": field_names,
        "key_entities_found": found,
        "key_entities_missing": missing,
        "full_schema": data
    })
    
    return len(found) >= 2  # Pass if at least workOrder and parts exist


def test_2_query_usefulness(client):
    """Test 2: Check if single queries return useful data."""
    print("\n" + "="*60)
    print("TEST 2: Single-Query Usefulness")
    print("="*60)
    
    results = {"tests": [], "summary": ""}
    
    # Test work order query
    print("  Testing work order query...")
    wo_query = """
    {
      workOrders(first: 1) {
        records {
          workOrderNumber
          status
          dueDate
          quantity
          customer {
            customerName
          }
          part {
            partNumber
            partDescription
          }
          ops {
            records {
              operationNumber
              status
            }
          }
        }
      }
    }
    """
    success, data = client.execute(wo_query)
    wo_result = {
        "query": "workOrders(first: 1)",
        "success": success,
        "fields_available": [],
        "notes": ""
    }
    
    if success and data.get("workOrders", {}).get("records"):
        record = data["workOrders"]["records"][0]
        wo_result["fields_available"] = list(record.keys())
        wo_result["sample"] = record
        wo_result["notes"] = "Work order query returns good detail including customer, part, operations"
        print(f"    ✓ Got WO with fields: {list(record.keys())}")
    else:
        wo_result["error"] = str(data) if not success else "No records returned"
        print(f"    ✗ Work order query failed or empty")
    
    results["tests"].append(wo_result)
    
    # Test parts query
    print("  Testing parts query...")
    parts_query = """
    {
      parts(first: 1) {
        records {
          partNumber
          partDescription
          operations {
            records {
              opNumber
              operationDescription
            }
          }
        }
      }
    }
    """
    success, data = client.execute(parts_query)
    parts_result = {
        "query": "parts(first: 1)",
        "success": success,
        "fields_available": [],
        "notes": ""
    }
    
    if success and data.get("parts", {}).get("records"):
        record = data["parts"]["records"][0]
        parts_result["fields_available"] = list(record.keys())
        parts_result["sample"] = record
        parts_result["notes"] = "Parts query works"
        print(f"    ✓ Got part with fields: {list(record.keys())}")
    else:
        parts_result["error"] = str(data) if not success else "No records returned"
        print(f"    ✗ Parts query failed or empty")
    
    results["tests"].append(parts_result)
    
    # Test contacts/customers
    print("  Testing contacts query...")
    contacts_query = """
    {
      contacts(first: 1) {
        records {
          firstName
          lastName
          company {
            customerName
          }
        }
      }
    }
    """
    success, data = client.execute(contacts_query)
    contacts_result = {
        "query": "contacts(first: 1)",
        "success": success,
    }
    
    if success:
        records = data.get("contacts", {}).get("records", [])
        if records:
            contacts_result["fields_available"] = list(records[0].keys())
            print(f"    ✓ Contacts query works")
        else:
            contacts_result["notes"] = "Query succeeded but no records"
            print(f"    ~ Contacts query returned empty")
    else:
        contacts_result["error"] = str(data)
        print(f"    ✗ Contacts query failed")
    
    results["tests"].append(contacts_result)
    
    # Summary
    passed = sum(1 for t in results["tests"] if t["success"])
    results["summary"] = f"{passed}/{len(results['tests'])} queries succeeded"
    
    log_result("02_query_usefulness.md", f"""# Test 2: Query Usefulness Results

**Date:** {datetime.now().isoformat()}

## Summary
{results['summary']}

## Tests Run

{json.dumps(results['tests'], indent=2)}

## Conclusion
{'PASS - Can get useful data from single queries' if passed >= 2 else 'FAIL - Queries not returning useful data'}
""")
    
    return passed >= 2


def test_3_auth_reliability(client):
    """Test 3: Check auth holds up under repeated queries."""
    print("\n" + "="*60)
    print("TEST 3: Auth Reliability")
    print("="*60)
    
    simple_query = "{ __typename }"
    successes = 0
    failures = []
    
    print("  Running 20 queries in sequence...")
    for i in range(20):
        success, data = client.execute(simple_query)
        if success:
            successes += 1
        else:
            failures.append({"attempt": i+1, "error": str(data)})
        
        if (i + 1) % 5 == 0:
            print(f"    Completed {i+1}/20...")
    
    print(f"  Results: {successes}/20 succeeded")
    
    result = f"""# Test 3: Auth Reliability Results

**Date:** {datetime.now().isoformat()}

## Summary
- Queries attempted: 20
- Successes: {successes}
- Failures: {len(failures)}

## Failures
{json.dumps(failures, indent=2) if failures else "None"}

## Conclusion
{'PASS - Auth is stable for repeated queries' if successes == 20 else 'FAIL - Auth issues detected'}
"""
    
    log_result("03_auth_reliability.md", result)
    return successes >= 18  # Allow up to 2 failures


def test_4_rate_limits(client):
    """Test 4: Check for rate limiting."""
    print("\n" + "="*60)
    print("TEST 4: Rate Limits")
    print("="*60)
    
    simple_query = "{ __typename }"
    results = []
    rate_limited = False
    
    print("  Firing 10 queries as fast as possible...")
    start_time = time.time()
    
    for i in range(10):
        query_start = time.time()
        success, data = client.execute(simple_query)
        query_time = time.time() - query_start
        
        results.append({
            "attempt": i + 1,
            "success": success,
            "time_ms": round(query_time * 1000, 2),
            "error": str(data) if not success else None
        })
        
        if not success and "429" in str(data):
            rate_limited = True
            print(f"    ✗ Rate limited at query {i+1}")
            break
    
    total_time = time.time() - start_time
    avg_time = sum(r["time_ms"] for r in results) / len(results)
    
    print(f"  Completed {len(results)} queries in {total_time:.2f}s (avg: {avg_time:.0f}ms)")
    
    result = f"""# Test 4: Rate Limit Results

**Date:** {datetime.now().isoformat()}

## Summary
- Queries attempted: {len(results)}
- Total time: {total_time:.2f}s
- Average query time: {avg_time:.0f}ms
- Rate limited: {'YES' if rate_limited else 'No'}

## Query Results
{json.dumps(results, indent=2)}

## Conclusion
{'FAIL - Rate limiting detected' if rate_limited else 'PASS - No rate limiting observed'}
"""
    
    log_result("04_rate_limits.md", result)
    return not rate_limited


def test_5_query_coverage(client):
    """Test 5: Map example questions to queries."""
    print("\n" + "="*60)
    print("TEST 5: Query Coverage Mapping")
    print("="*60)
    
    # Define example questions and their query feasibility
    questions = [
        ("What's the status of WO 25-0001?", "EASY", "workOrder(workOrderNumber: X) → status"),
        ("Show me all open work orders", "EASY", "workOrders(filter: {status: 'Open'})"),
        ("What work orders are due this week?", "MEDIUM", "workOrders with date filter"),
        ("What operations are on part XYZ?", "EASY", "parts(filter: {partNumber: X}) → operations"),
        ("Who is the contact for customer ABC?", "MEDIUM", "Need to query contacts with company filter"),
        ("What's the current operation for WO 25-0001?", "MEDIUM", "workOrder → ops, filter by status"),
        ("Show me R2Sonic's open orders", "MEDIUM", "workOrders with customer filter"),
        ("What tools are needed for Op 60 on part XYZ?", "EASY", "parts → operations → tools"),
        ("When is WO 25-0001 due?", "EASY", "workOrder → dueDate"),
        ("How many open work orders do we have?", "EASY", "workOrders count"),
        ("What work orders were shipped last week?", "MEDIUM", "workOrders with date/status filter"),
        ("Show me all parts for customer R2Sonic", "MEDIUM", "parts with customer filter"),
        ("What's the job number for WO 25-0001?", "EASY", "workOrder → jobNumber"),
        ("Are there any late work orders?", "MEDIUM", "workOrders, compare dueDate to today"),
        ("What operations need to be run today?", "COMPLEX", "Need schedule data, may not be in API"),
        ("Show me the sequence details for part XYZ Op 60", "EASY", "parts → operations → tools"),
        ("What's the priority of WO 25-0001?", "EASY", "workOrder → priority"),
        ("Who is assigned to WO 25-0001?", "MEDIUM", "workOrder → assignment fields"),
        ("What's the quantity for WO 25-0001?", "EASY", "workOrder → quantity"),
        ("Show me all work orders in 'In Process' status", "EASY", "workOrders(filter: {status: 'In Process'})"),
    ]
    
    easy = sum(1 for q in questions if q[1] == "EASY")
    medium = sum(1 for q in questions if q[1] == "MEDIUM")
    complex_q = sum(1 for q in questions if q[1] == "COMPLEX")
    impossible = sum(1 for q in questions if q[1] == "IMPOSSIBLE")
    
    feasible = easy + medium  # Both easy and medium are feasible
    total = len(questions)
    pct = (feasible / total) * 100
    
    print(f"  EASY: {easy}")
    print(f"  MEDIUM: {medium}")
    print(f"  COMPLEX: {complex_q}")
    print(f"  IMPOSSIBLE: {impossible}")
    print(f"  Feasible: {feasible}/{total} ({pct:.0f}%)")
    
    result = f"""# Test 5: Query Coverage Mapping

**Date:** {datetime.now().isoformat()}

## Summary
- Total questions: {total}
- EASY (single query): {easy}
- MEDIUM (filtering/chaining): {medium}
- COMPLEX (may need workaround): {complex_q}
- IMPOSSIBLE (not in API): {impossible}
- **Feasible (EASY + MEDIUM): {feasible}/{total} ({pct:.0f}%)**

## Question Mapping

| Question | Difficulty | Approach |
|----------|------------|----------|
"""
    
    for q, diff, approach in questions:
        result += f"| {q} | {diff} | {approach} |\n"
    
    result += f"""
## Conclusion
{'PASS - 80%+ of questions are feasible' if pct >= 80 else 'PARTIAL - Some questions may require workarounds' if pct >= 60 else 'FAIL - Too many questions are not feasible'}
"""
    
    log_result("05_query_coverage.md", result)
    return pct >= 80


def generate_go_no_go(test_results):
    """Generate final go/no-go recommendation."""
    print("\n" + "="*60)
    print("GENERATING GO/NO-GO RECOMMENDATION")
    print("="*60)
    
    passed = sum(test_results.values())
    total = len(test_results)
    
    # Determine recommendation
    if passed == total:
        recommendation = "GO"
        summary = "All tests passed. Project is viable."
    elif test_results.get("schema", False) and test_results.get("usefulness", False):
        recommendation = "GO WITH CAVEATS"
        summary = "Core functionality available. Some issues to address."
    elif not test_results.get("schema", False):
        recommendation = "NO-GO"
        summary = "Schema does not expose required queries. Cannot proceed."
    else:
        recommendation = "INVESTIGATE FURTHER"
        summary = "Mixed results. Need more analysis before deciding."
    
    result = f"""# ProShop Conversational Interface - Feasibility Assessment

**Date:** {datetime.now().isoformat()}

## Test Results

| Test | Result |
|------|--------|
| 1. Schema Discovery | {'PASS' if test_results.get('schema') else 'FAIL'} |
| 2. Query Usefulness | {'PASS' if test_results.get('usefulness') else 'FAIL'} |
| 3. Auth Reliability | {'PASS' if test_results.get('auth') else 'FAIL'} |
| 4. Rate Limits | {'PASS' if test_results.get('rate_limits') else 'FAIL'} |
| 5. Query Coverage | {'PASS' if test_results.get('coverage') else 'FAIL'} |

**Overall: {passed}/{total} tests passed**

## Recommendation

# {recommendation}

{summary}

## Next Steps

"""
    
    if recommendation == "GO":
        result += """1. Proceed to Phase 1: Build query template library
2. Create intent classifier for natural language mapping
3. Build CLI interface
"""
    elif recommendation == "GO WITH CAVEATS":
        result += """1. Review failed tests and determine workarounds
2. Document limitations for users
3. Proceed with reduced scope if acceptable
"""
    elif recommendation == "NO-GO":
        result += """1. Investigate REST API alternatives
2. Contact ProShop support about missing endpoints
3. Consider browser automation as alternative
"""
    else:
        result += """1. Re-run failed tests with debugging
2. Investigate specific failures
3. Make decision after additional analysis
"""
    
    log_result("00_GO_NO_GO.md", result)
    print(f"\n  Recommendation: {recommendation}")
    return recommendation


def main():
    print("="*60)
    print("ProShop Conversational Interface - Feasibility Spike")
    print("="*60)
    print(f"Started: {datetime.now().isoformat()}")
    
    # Check for credentials
    client_id = os.environ.get("PROSHOP_CLIENT_ID", DEFAULT_CLIENT_ID)
    client_secret = os.environ.get("PROSHOP_CLIENT_SECRET", "")
    
    if not client_secret:
        # Check for CREDENTIALS.md
        creds_file = Path(__file__).parent / "CREDENTIALS.md"
        if creds_file.exists():
            print("\nFound CREDENTIALS.md but couldn't parse it.")
            print("Please set PROSHOP_CLIENT_SECRET environment variable.")
        else:
            print("\n✗ Missing credentials!")
            print("\nSet environment variable:")
            print("  export PROSHOP_CLIENT_SECRET='your_secret_here'")
            print("\nOr create CREDENTIALS.md with:")
            print("  CLIENT_SECRET=your_secret_here")
            
            # Create template
            template = """# ProShop API Credentials

**DO NOT COMMIT THIS FILE**

```
export PROSHOP_CLIENT_ID="3923-9C1C-7291"
export PROSHOP_CLIENT_SECRET="[GET FROM WOLFGANG]"
```
"""
            with open(creds_file, "w") as f:
                f.write(template)
            print(f"\nCreated template: {creds_file}")
        
        sys.exit(1)
    
    # Initialize client
    client = ProShopClient()
    
    # Authenticate
    print("\nAuthenticating...")
    success, message = client.authenticate(client_id, client_secret)
    if not success:
        print(f"✗ Authentication failed: {message}")
        sys.exit(1)
    print(f"✓ {message}")
    
    # Run tests
    test_results = {}
    
    try:
        test_results["schema"] = test_1_schema_discovery(client)
        test_results["usefulness"] = test_2_query_usefulness(client)
        test_results["auth"] = test_3_auth_reliability(client)
        test_results["rate_limits"] = test_4_rate_limits(client)
        test_results["coverage"] = test_5_query_coverage(client)
    except Exception as e:
        print(f"\n✗ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Generate recommendation
    recommendation = generate_go_no_go(test_results)
    
    print("\n" + "="*60)
    print("FEASIBILITY SPIKE COMPLETE")
    print("="*60)
    print(f"Results in: {RESULTS_DIR}")
    print(f"Recommendation: {recommendation}")
    
    return 0 if recommendation in ["GO", "GO WITH CAVEATS"] else 1


if __name__ == "__main__":
    sys.exit(main())
