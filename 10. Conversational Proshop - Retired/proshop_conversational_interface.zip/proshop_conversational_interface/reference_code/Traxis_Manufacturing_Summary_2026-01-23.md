# Traxis Manufacturing — Company Summary

**Date:** January 23, 2026  
**Purpose:** Background context for Claude projects

---

## Company Overview

**Traxis Manufacturing** is a precision CNC machine shop in Austin, TX serving automotive suppliers and specialty customers.

| Attribute | Value |
|-----------|-------|
| Location | Austin, TX (near St. Elmo Road) |
| Active Customers | ~20 |
| Monthly Orders | ~20 |
| Precision Capability | 12 microns (0.0005") |
| Certifications | None (pursuing ISO 9001 and AS9100) |

### Key Customer

**R2Sonic** — Manufacturer of multibeam sonar systems for hydrographic surveying. Traxis produces plastic and titanium precision components for their underwater acoustic equipment. Largest account (~50% revenue). 15-year relationship.

**Other Customers:** ARL, local 3D concrete printing company, various automotive suppliers.

**Work Types:** Small turned parts, enclosure modifications, general job shop variety.

---

## Team (5 people)

| Role | Person | Responsibilities |
|------|--------|------------------|
| Primary Programmer | Garrett | CAM programming (Fusion 360) |
| Secondary Programmer | Wolfgang | CAM programming, automation development, post processors |
| Purchasing/Operations | Rene | Order processing, purchasing, machine operation |
| Setup & Inspection | Chris | Machine setup, inspection specialist |
| Operator | Jose | Machine operation |

---

## Equipment

### CNC Mills (8)

| ID | Machine | Control | Taper | Work Envelope |
|----|---------|---------|-------|---------------|
| Mill-1 | Haas VF5 | Haas | 40T | 50×25 |
| Mill-2 | Smec #1 | Fanuc | 40T | 30×16 |
| Mill-3 | Smec #2 | Fanuc | 40T | 30×16 |
| Mill-4 | Black Robodrill | Fanuc | 30T | 16×12 |
| Mill-5 | White Robodrill | Fanuc | 30T | ~20×15 |
| Mill-6 | Chevalier EM2040L | Fanuc 0i-MF | 40T | 40×20 |
| Mill-7 | 5-axis Robodrill | Fanuc | — | 5-axis table mount |
| Mill-8 | Hyundai-Wia KF5600II | Fanuc | 40T | 40×20 |

### CNC Lathes (2)

| ID | Machine | Control | Specs |
|----|---------|---------|-------|
| T1 | Okuma Lathe | Okuma | 13" chuck, 3" spindle tube, ~21" Z travel |
| T2 | YCM NTC1600LY | Fanuc 0i-TF | Mill-turn, live tooling, Y-axis, 2" spindle tube, 6" chuck, 3J collet |

### Manual & Support Equipment

- DoAll Manual Lathe (collet & 3-jaw)
- Bridgeport Manual Mill (knee mill)
- Horizontal Bandsaw
- DoAll Surface Grinder

---

## Software & Systems

| System | Purpose |
|--------|---------|
| **Fusion 360** | CAM programming |
| **ProShop ERP** | Manufacturing execution, work orders, scheduling, process documentation |
| **Airtable + Softr** | Customer portal (RFQs, order tracking) |
| **Make.com** | Automation workflows |
| **Custom Post Processors** | G-code generation for each machine |

### ProShop ERP Details

- **Instance:** traxismfg.adionsystems.com
- **GraphQL API:** `https://traxismfg.adionsystems.com/api/graphql`
- **Token Endpoint:** `/home/member/oauth/accesstoken`
- **Client ID:** `3923-9C1C-7291`
- **Login Username:** `tbuerkle`
- **Annual Cost:** ~$13k/year ($3,630 for API access)

---

## Active Development Projects

### 1. ProShop Automations (Fusion 360 → ProShop)

**Status:** ✅ Working (hybrid approach)

**Purpose:** Export CAM data from Fusion 360 and push to ProShop ERP automatically.

**Components:**
- `ExportToProShop.py` — Fusion 360 script that exports JSON + screenshots
- `proshop_gui_v1.4.py` — Python GUI for pushing data to ProShop
- Custom post processors with JSON sidecar file generation

**Technical Flow:**
1. Run export script in Fusion 360 → creates JSON with setup/tool data
2. Run Python GUI → select setup, enter part number and op number
3. **Sequence Details:** Pushed via GraphQL API (working)
4. **Written Descriptions:** Pushed via Selenium (workaround for API bug)

**Known Issue — ProShop Written Description Bug:**
- Data written via API stores correctly but doesn't display in UI
- Root cause: API sets `legacyId: ""` instead of `null`
- Workaround: Use Selenium for written descriptions
- Bug report sent to ProShop support

**Key Technical Details:**
- Fusion 360 stores measurements in centimeters (divide by 2.54 for inches)
- "Length below holder" field = internal parameter `tool_bodyLength`
- Program number convention: trailing digits + setup index (e.g., O1451, O1452)

---

### 2. YCM NTC1600LY Post Processor

**Status:** ✅ Production  
**Current Version:** v1.7.005 (December 29, 2025)  
**Machine:** YCM NTC1600LY CNC Lathe  
**Control:** Fanuc 0i-TF

**Key Features:**
- Live tooling support (M68 turning / M69 live tool, positions 2, 4, 6)
- Y-axis always enabled (G28 V0. in all retracts)
- Bar puller automation (trigger with "puller" in Manual NC comment)
- Material stop automation (trigger with "material stop" comment)
- Parts catcher control (M27/M28 extend/retract, M84/M85 door)
- ProShop ERP integration (operation data block at end of NC file)
- Peck tapping with complete G84 line output for each peck
- Pass-through support for C-axis indexing

**Version Update Procedure (5 locations):**
1. Header comment (VERSION / BUILD DATE)
2. Changelog entry
3. `POST_VERSION` variable (~line 256)
4. `POST_BUILD_DATE` variable (~line 257)
5. Filename: `YCM_NTC1600LY_vX_Y_ZZZ.cps`

**Known Limitations:**
- Only ZX plane circular interpolation allowed (G17/G19 cause alarm)
- No automatic XY → C-axis conversion (use Manual NC pass-through)

---

### 3. Customer Portal (Airtable + Softr)

**Status:** ✅ Core functionality working

**Purpose:** Customer-facing portal for RFQ submission and order tracking.

**Architecture:**
```
Customer → Softr Portal → Airtable (database) → Make.com (automation)
                                                    ↓
                                              ProShop ERP
                                              Dropbox (files)
```

**Features:**
- Customer login (email/password, no self-signup)
- RFQ submission with file upload (drawings, CAD)
- Order status tracking
- Inspection report/material cert downloads

**Airtable Schema:**
- **Orders Table:** Part Number, Revision, Quantity, Status, Contact Email, Traxis WO, Drawing PDF, CAD Model, Inspection Report, etc.
- **Users Table:** Contact Name, Company, Email, ProShop Prefix, Dropbox Folder Name

**Status Values (in order):**
1. RFQ Submitted → 2. Quoting → 3. Quoted → 4. Order Placed → 5. In Production → 6. Shipped → 7. Complete

**Make.com Scenarios:**
- RFQ File Handler — Creates Dropbox folders, uploads files, emails sales team
- Auto Status Update — Flips status to "In Production" when WO number added
- ProShop Inspection Sync — Pulls inspection reports from ProShop nightly

**File Structure (Dropbox):**
```
/PART FILES Traxis/[Customer Folder]/[Part Number]/[Revision]/
  ├── Drawing.pdf
  └── Model.step
```

---

### 4. Inspection Print & Dimension Extraction

**Status:** 🔄 In Progress (blocked)

**Purpose:** Automatically extract dimensions from engineering drawings and push to ProShop as In-Process Check (IPC) rows.

**Architecture:**
```
Airtable (Order Placed) → Download PDF → Google Document AI → Extract Dimensions → ProShop API
```

**Google Cloud Setup:**
- Project: `traxis-dimension-extraction`
- Document AI Processor: Form Parser (ID: `7998f6b47340a362`)
- Cloud Function: `process-drawing` (Python 3.11)

**ProShop IPC Mutation (confirmed working):**
```graphql
mutation {
  updatePart(partNumber: "PREFIX-PARTNUMBER", data: {
    operations: [{
      selector: { field: opNumber, value: "2000" }
      data: {
        inProcessCheck: [{
          data: {
            dimTagNumber: "1"
            nominalDim: "25.40"
            characterDesignation: "diameter"
            drawingSpec: "Ø25.40"
          }
        }]
      }
    }]
  }) { partNumber }
}
```

**Current Blocker:** Google account (tom@traxismfg.com) was disabled 2026-01-18. Appeal in progress.

---

### 5. Hyundai KF5600II Post Processor

**Status:** ✅ Production  
**Current Version:** v1.1.2  
**Machine:** Hyundai-Wia KF5600II  
**Control:** Fanuc

**Reference:** `hyundai_kf5600ii_gm_codes.md` contains complete G/M code documentation.

---

### 6. Chevalier EM2040L Post Processor

**Status:** ✅ Production  
**Current Version:** v1.3.6 (January 12, 2026)  
**Machine:** Chevalier EM2040L Vertical Milling Center  
**Control:** Fanuc 0i-MF

**Key Features:**
- Based on SMT VMC FANUC PS EXPORT V5 post
- Safe retract: G28 (changed from G30)
- Through-spindle coolant: M17 on / M18 off
- Air blow: M31 on / M32 off
- T99 edge finder handling (manual tool with M00 stop)
- G28 Y retract before every tool change (tall fixture clearance)
- ProShop integration (tool list header, operation data block)
- Standard peck tapping with Q parameter

**Recent Fix (v1.3.6):** Fixed peck tapping crash with multi-hole patterns — now uses standard G84/G74 with Q parameter instead of expanded peck tapping.

---

### 7. Customer Outreach

**Status:** 📋 Planning

**Objective:** Reduce customer concentration risk by acquiring new customers.

**Background:**
- Over-dependence on R2Sonic (~50% revenue)
- Risk factors: customer establishing offshore manufacturing, potential capability replication
- Historical difficulty with sales and self-promotion

**Target: Saronic Technologies**
- Autonomous naval vessel manufacturer (unicorn company)
- Located nearby on Industrial Boulevard
- Marine/naval focus aligns with R2Sonic and ARL experience

**Identified Contacts:**
- Kevin Kaufmann (Manufacturing Engineering) — primary target
- Lucas Volk (Supply Chain Management) — secondary

**Status:**
- [x] Identified Saronic as prime target
- [x] Researched key contacts
- [x] Drafted outreach email
- [ ] Send initial outreach
- [ ] Follow up / establish relationship

---

### 8. Catastrophe Planning

**Status:** 📋 Paused (focus shifted to customer diversification)

**Key Risk Areas Identified:**
1. **Key Personnel Loss** — Critical knowledge concentrated in limited staff
2. **Economic Downturns** — Cyclical exposure to manufacturing sector
3. **Major Customer Dependency (Critical)** — R2Sonic represents ~50% revenue

**Current Focus:** Customer diversification has become the urgent priority. Broader catastrophe planning tabled until diversification efforts are underway.

---

### 9. Shop Floor Automations / Machine Monitoring

**Status:** 📋 Research complete, implementation pending

**Goal:** Photo documentation triggered by cycle complete, integrated with ProShop.

**Options Evaluated:**
1. **Hardwired DO Signal** — Ladder triggers 24V output on cycle complete
2. **FOCAS/Ethernet Polling** — Poll machine status over network
3. **Hybrid** (recommended) — Hardwired for trigger, FOCAS for metadata

**FOCAS Compatibility:**
- All "i" series Fanuc controls (16i, 18i, 21i, 0i-F, 30i, etc.) support FOCAS
- Oldest machine (16i) is compatible
- Default FOCAS port: 8193

**Alternative Explored:** Current transformer (CT) sensors + ESP32 for utilization monitoring

---

## File Locations

| Content | Path |
|---------|------|
| Project Files | `D:\Dropbox\MACHINE COMM Traxis\Proshop Automation and Claude Projects\` |
| ProShop Exports | `D:\Dropbox\MACHINE COMM Traxis\ProShop Exports\` |
| Fusion Scripts | `%appdata%\Autodesk\Autodesk Fusion 360\API\Scripts\` |
| Fusion Posts | `%appdata%\Autodesk\Autodesk Fusion 360\CAM\Posts\` |
| NC Programs | `Documents\Fusion 360\NC Programs\` |

---

## ProShop API Quick Reference

**Authentication:**
```
POST /home/member/oauth/accesstoken
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id=3923-9C1C-7291&client_secret=[SECRET]&scope=parts:rwdp+workorders:rwdp
```

**GraphQL Endpoint:** `https://traxismfg.adionsystems.com/api/graphql`

**Working Mutations:**
- Update Sequence Details (tools, holders, OOH)
- Add IPC rows to operations
- Query work orders, parts, contacts

**Known Limitations:**
- Written Description API bug (use Selenium workaround)
- Parts query filter seems broken (returns empty for known parts)
- Work order nested filter by PO number doesn't work (fetch all, match client-side)

---

## Business Context

### Competitive Advantages
- 12-micron precision capability
- Marine industry experience (R2Sonic, ARL)
- Local Austin presence for quick-turn work
- Multi-material capability (aluminum, stainless, titanium, plastics)
- Established process documentation via ProShop

### Strategic Priorities
1. **Customer Diversification** — Reduce R2Sonic dependency
2. **Certification** — Pursue ISO 9001 and AS9100 for higher-value work
3. **Automation** — Continue Fusion→ProShop integration and workflow improvements

### Known Challenges
- Customer concentration risk (single customer ~50% revenue)
- No certifications (limits access to aerospace/defense work)
- Historical difficulty with sales and customer outreach
- Small team (knowledge concentration risk)

---

## Customer Portal To-Do

- [ ] Airtable automation to auto-fill File_Type field (requires plan upgrade)
- [ ] Auto-upload material certs/inspection reports for customer download
- [ ] Auto-sync WO numbers from ProShop (match by Customer PO Number)
- [ ] Customer notification when quote is ready
- [ ] 30-day cleanup of unconverted RFQ folders

---

## Contacts & Accounts

| Service | Account/Instance |
|---------|------------------|
| ProShop | traxismfg.adionsystems.com |
| Airtable | Traxis Customer Portal base |
| Softr | Customer-facing portal |
| Make.com | Automation scenarios |
| Dropbox | tom@traxismfg.com |
| Google Cloud | traxis-dimension-extraction project |

---

## Notes for Claude

- Wolfgang is the primary contact for automation and programming projects
- ProShop login username is `tbuerkle`
- When working on post processors, always update all version locations (4-5 places depending on post)
- Fusion 360 measurements are in centimeters
- ProShop Written Descriptions require Selenium (API has display bug)
- Customer portal scenarios are built but inactive—activate when going live
- YCM post: 5 version locations; other posts: 4 locations typically
