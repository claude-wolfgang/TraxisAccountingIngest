# ProShop Written Description API Bug - Investigation Summary

**Date:** 2026-01-20  
**Status:** Bug confirmed, workaround implemented, report sent to ProShop

---

## Problem

Data written to `writtenDescriptions` via the GraphQL API is stored in the database but does not display in the ProShop web UI.

---

## Root Cause Found

| Entry Method | legacyId Value | Displays in UI? |
|--------------|----------------|-----------------|
| UI (manual)  | `null`         | ✓ Yes           |
| API (GraphQL)| `""` (empty string) | ✗ No       |

The API sets `legacyId: ""` instead of `null`. The UI skips rendering records with empty string legacyId. The field is **not writable** via mutation, so there's no API-side workaround.

---

## Key Findings

1. **Mutation succeeds** - data is stored in database
2. **Link turns black** - ProShop detects content exists
3. **UI shows blank** - renderer skips records where `legacyId == ""`
4. **Corruption is permanent** - even UI re-save doesn't fix it
5. **No alternative mutations** - `updatePartOperation` and `updateWorkOrderOperation` don't have `writtenDescriptions` field

---

## Useful Queries Discovered

**Query written descriptions via work order:**
```graphql
{
  workOrder(workOrderNumber: "25-0001") {
    ops {
      records {
        operationNumber
        partOperation {
          writtenDescriptions {
            records {
              legacyId
              writtenDescription
            }
          }
        }
      }
    }
  }
}
```

**Parts query doesn't find parts reliably** - filter seems broken, returns empty even for known part numbers.

---

## Workarounds Attempted (Failed)

- ✗ Plain text (no HTML) - still blank
- ✗ Escaped newlines vs actual newlines - API error or still blank
- ✗ UI re-save after API write - doesn't fix corruption
- ✗ Alternative mutations - don't have writtenDescriptions field

---

## Solution Implemented

**Hybrid approach:**
- **Sequence Details:** GraphQL API (works correctly)
- **Written Descriptions:** Selenium browser automation (workaround)

---

## Files Created

| File | Purpose |
|------|---------|
| `proshop_bug_report.pdf` | Formal bug report sent to ProShop support |
| `proshop_gui_v1.1.py` | Updated GUI using Selenium for written descriptions |
| `proshop_selenium.py` | Standalone Selenium module for written descriptions |

---

## GUI v1.1 Changes

- Two auth sections: API credentials + Web login credentials
- Sequence details → API (unchanged)
- Written descriptions → Selenium (new)
- Headless mode checkbox
- Requires both connections before push is enabled

---

## Next Steps

1. Test Selenium script with `headless=False` to verify selectors
2. Adjust login/editor/button selectors if needed
3. Wait for ProShop to fix the API bug (estimated: long time)

---

## Memory Update Needed

Add to memory:
- ProShop Written Description API bug: `legacyId=""` vs `null` causes UI not to render
- Workaround: Use Selenium for written descriptions, API for sequence details
- GUI v1.1 implements this hybrid approach
