# ProShop Automation Project State

**Last Updated:** 2026-01-16
**Status:** ✅ API Authentication WORKING!

---

## ProShop API Authentication (WORKING)

**Token Endpoint:** `/home/member/oauth/accesstoken`
**Content-Type:** `application/x-www-form-urlencoded`
**Method:** POST

**Request body:**
```
grant_type=client_credentials&client_id=3923-9C1C-7291&client_secret=[SECRET]&scope=parts:rwdp+workorders:rwdp
```

**Response:**
```json
{
  "access_token": "...",
  "token_type": "Bearer",
  "expires_in": 86400
}
```

**Use token:** `Authorization: Bearer [access_token]` header on GraphQL requests

**Note:** The Python `getpass` hidden input has issues with pasting on Windows. Use visible input instead.

---

## Current System Overview

### Components

| Component | Version | Status | Location |
|-----------|---------|--------|----------|
| ExportToProShop.py | v6 | ✅ Working | Fusion 360 Scripts folder |
| proshop_graphql.py | v1.0 | ⏳ Waiting for API access | Dropbox/Proshop Automations Shared |
| SMT VMC Post | V6 | ✅ Working | Fusion 360 Posts |
| Robodrill Post | v2 | ✅ Working | Fusion 360 Posts |
| YCM Lathe Post | v1.7.004 | ✅ Working | Fusion 360 Posts |

### ProShop API Details

- **Endpoint:** `https://traxismfg.adionsystems.com/api/graphql`
- **Auth Endpoint:** `https://traxismfg.adionsystems.com/api/beginsession`
- **Auth Method:** OAuth 2.0 Client Credentials OR beginsession with username/password
- **Type:** GraphQL

**To get credentials (requires admin):**
1. System Config → Manage Authorizations
2. Create authorization with "Direct Login" checked
3. Note the "Unique ID" (client_id) and "Shared Secret" (client_secret)

### Verified Working Mutations

**Update Written Description:**
```graphql
mutation {
  updatePart(partNumber: "PART_NUM", data: {
    operations: [{
      selector: { field: opNumber, value: "60" },
      data: {
        writtenDescriptions: { writtenDescription: "<p>HTML content</p>" }
      }
    }]
  }) {
    partNumber
  }
}
```

**Update Sequence Details (Tools):**
```graphql
mutation {
  updatePart(partNumber: "PART_NUM", data: {
    operations: [{
      selector: { field: opNumber, value: "60" },
      data: {
        tools: [{
          selector: { field: sequenceNumber, value: "1" },
          data: {
            tool: "TOOL_ID",
            outOfHolder: "2.5",
            holder: "HOLDER_NAME",
            sequenceDescription: "Operation description"
          }
        }]
      }
    }]
  }) {
    partNumber
  }
}
```

### Available Tool Fields for Update
- sequenceNumber
- tool (tool ID)
- outOfHolder (OOH)
- holder
- sequenceDescription
- ncDescription
- latheToolLocation, latheToolNose, latheToolRad (for lathe)
- gTypeInsert, gTypeQuantity (for indexable tools)

---

## Key Technical Discoveries

### Fusion 360 API
- "Length below holder" field uses internal parameter name `tool_bodyLength` (NOT `tool_lengthBelowHolder`)
- Use this for OOH values in exports

### ProShop Post-Processor Format
- Sanitize toolId/holder: replace spaces→underscores, slashes→dashes
- Use "-" if empty
- Format: `(SEQ #   TOOL_ID  T#  OOH #.####  HOLDER holder   desc)`

### ProShop Page Structure
- Each ProShop Operation (Op 60, 70, etc.) = One Fusion Setup
- **Sequence Detail page:** Tool data (tool ID, number, OOH, holder, description)
- **Written Description page:** Setup info, screenshots, NC files

---

## Workflow

### Current (API-based - NEW)
1. Run ExportToProShop in Fusion 360 → creates JSON + screenshots
2. Run proshop_graphql.py
3. Select setup, enter ProShop part number and op number
4. Script pushes data directly via GraphQL API

### Previous (Selenium-based - DEPRECATED)
1. Export from Fusion
2. Start Chrome with --remote-debugging-port=9222
3. Navigate to ProShop page, checkout
4. Run Selenium script
5. Manual save

---

## Next Steps / TODO

- [ ] File uploads via API (NC files, screenshots) - may need separate endpoint
- [ ] Batch mode - push all setups at once
- [ ] Convert to GUI application
- [ ] Add to Fusion as toolbar button add-in

---

## File Locations

- **Fusion Scripts:** `%appdata%\Autodesk\Autodesk Fusion 360\API\Scripts\`
- **Fusion Posts:** `%appdata%\Autodesk\Autodesk Fusion 360\CAM\Posts\`
- **Export Output:** `C:\ProShopExport\[part_name]\`
- **NC Files:** `Documents\Fusion 360\NC Programs\`
- **Automation Scripts:** `C:\Users\TRAXIS\Dropbox\MACHINE COMM Traxis\Proshop Automation\`

---

## Program Number Convention
- Extract trailing numbers from part name
- Append setup index (1, 2, 3...)
- Example: Part "145 Furnace Support" → O1451, O1452, O1453

---

## Contact/Notes
- ProShop API cost: $3,630/year
- ProShop total cost: ~$13k/year
- Customer portal planned - API enables concurrent users
