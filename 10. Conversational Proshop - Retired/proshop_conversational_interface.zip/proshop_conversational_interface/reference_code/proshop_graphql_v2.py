"""
ProShop GraphQL API Client
Direct API integration for Fusion 360 CAM data

Features:
- OAuth 2.0 authentication
- Interactive setup-to-operation mapping with save/reuse
- Batch push all setups at once
- Written descriptions and sequence details

Endpoint: https://traxismfg.adionsystems.com/api/graphql
Auth: OAuth 2.0 Client Credentials

Usage:
    python proshop_graphql.py

Version: 2.0
"""

import requests
import json
import os
from datetime import datetime
from pathlib import Path

# Configuration
DROPBOX_ROOT = os.path.expandvars(r"%USERPROFILE%\Dropbox")
EXPORTS_FOLDER = os.path.join(DROPBOX_ROOT, "MACHINE COMM Traxis", "ProShop Exports")
PROSHOP_BASE_URL = "https://traxismfg.adionsystems.com"

# Default credentials (can be overridden)
DEFAULT_CLIENT_ID = "3923-9C1C-7291"


class ProShopGraphQL:
    def __init__(self, base_url=PROSHOP_BASE_URL):
        self.base_url = f"{base_url}/api/graphql"
        self.base_root = base_url
        self.session = requests.Session()
        self.authenticated = False
        self.access_token = None
    
    def authenticate_oauth(self, client_id, client_secret):
        """
        Authenticate using OAuth 2.0 Client Credentials Flow.
        """
        endpoint = f"{self.base_root}/home/member/oauth/accesstoken"
        
        # Build the body exactly as ProShop docs show - including scope
        scope = "parts:rwdp+workorders:rwdp"
        body = f"grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&scope={scope}"
        
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        
        print(f"  Authenticating...")
        
        try:
            response = requests.post(endpoint, data=body, headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("access_token"):
                    self.access_token = data.get("access_token")
                    self.session.headers.update({
                        "Authorization": f"Bearer {self.access_token}",
                        "Content-Type": "application/json"
                    })
                    self.authenticated = True
                    
                    expires_in = data.get("expires_in", 86400)
                    print(f"  ✓ Authenticated! Token valid for {expires_in // 3600} hours")
                    return True
                elif data.get("error"):
                    print(f"  ✗ Error: {data.get('error')} - {data.get('error_description')}")
                    return False
            else:
                print(f"  ✗ Auth failed ({response.status_code})")
                return False
                
        except Exception as e:
            print(f"  ✗ Auth error: {e}")
            return False
        
        return False
    
    def execute(self, query, variables=None):
        """Execute a GraphQL query or mutation"""
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        
        response = self.session.post(self.base_url, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"API Error {response.status_code}: {response.text}")
        
        result = response.json()
        if "errors" in result:
            raise Exception(f"GraphQL Error: {json.dumps(result['errors'], indent=2)}")
        
        return result.get("data")
    
    def get_part(self, part_number):
        """Get part details including operations"""
        query = """
        query GetPart($partNumber: [String!]!) {
          parts(filter: { partNumber: $partNumber }) {
            records {
              partNumber
              partDescription
              operations {
                records {
                  opNumber
                  operationDescription
                  writtenDescriptions {
                    records {
                      legacyId
                      writtenDescription
                    }
                  }
                  tools {
                    records {
                      sequenceNumber
                      outOfHolder
                      holder
                      sequenceDescription
                    }
                  }
                }
              }
            }
          }
        }
        """
        result = self.execute(query, {"partNumber": [part_number]})
        records = result.get("parts", {}).get("records", [])
        return records[0] if records else None
    
    def get_written_description(self, part_number, op_number):
        """Get existing written description for an operation"""
        part = self.get_part(part_number)
        if not part:
            return ""
        
        for op in part.get("operations", {}).get("records", []):
            if op.get("opNumber") == op_number:
                wd_records = op.get("writtenDescriptions", {}).get("records", [])
                if wd_records:
                    return wd_records[0].get("writtenDescription", "") or ""
        return ""
    
    def update_written_description(self, part_number, op_number, content, prepend=True):
        """
        Update written description for an operation.
        
        Args:
            part_number: Part number string
            op_number: Operation number string (e.g., "60")
            content: New HTML content to add
            prepend: If True, add new content on top; if False, replace entirely
        """
        if prepend:
            # Get existing content and prepend new content on top
            existing = self.get_written_description(part_number, op_number)
            if existing:
                content = content + "\n<hr>\n" + existing
        
        mutation = """
        mutation UpdateWrittenDescription($partNumber: String!, $opNumber: String!, $content: String!) {
          updatePart(partNumber: $partNumber, data: {
            operations: [{
              selector: { field: opNumber, value: $opNumber },
              data: {
                writtenDescriptions: { writtenDescription: $content }
              }
            }]
          }) {
            partNumber
          }
        }
        """
        
        variables = {
            "partNumber": part_number,
            "opNumber": op_number,
            "content": content
        }
        
        return self.execute(mutation, variables)
    
    def update_multiple_sequence_details(self, part_number, op_number, tools_list):
        """
        Update multiple sequence details at once.
        
        Args:
            part_number: Part number string
            op_number: Operation number string
            tools_list: List of dicts with keys: sequenceNumber, tool, outOfHolder, holder, sequenceDescription
        """
        # Build the tools array for the mutation
        tools_input = []
        for t in tools_list:
            tools_input.append({
                "selector": {"field": "sequenceNumber", "value": str(t.get("sequenceNumber", "1"))},
                "data": {
                    "tool": t.get("tool", ""),
                    "outOfHolder": str(t.get("outOfHolder", "")),
                    "holder": t.get("holder", ""),
                    "sequenceDescription": t.get("sequenceDescription", "")
                }
            })
        
        mutation = """
        mutation UpdateSequenceDetails($partNumber: String!, $opNumber: String!, $tools: [UpdatePartOperationToolInput!]!) {
          updatePart(partNumber: $partNumber, data: {
            operations: [{
              selector: { field: opNumber, value: $opNumber },
              data: {
                tools: $tools
              }
            }]
          }) {
            partNumber
          }
        }
        """
        
        variables = {
            "partNumber": part_number,
            "opNumber": op_number,
            "tools": tools_input
        }
        
        return self.execute(mutation, variables)


# =============================================================================
# FUSION EXPORT INTEGRATION
# =============================================================================

def list_export_folders():
    """List all available export folders in Dropbox"""
    if not os.path.exists(EXPORTS_FOLDER):
        print(f"  Exports folder not found: {EXPORTS_FOLDER}")
        return []
    
    folders = []
    for item in os.listdir(EXPORTS_FOLDER):
        item_path = os.path.join(EXPORTS_FOLDER, item)
        if os.path.isdir(item_path):
            # Check if it has a proshop_data.json
            json_path = os.path.join(item_path, "proshop_data.json")
            if os.path.exists(json_path):
                # Get modification time
                mtime = os.path.getmtime(json_path)
                folders.append({
                    "name": item,
                    "path": item_path,
                    "json_path": json_path,
                    "modified": datetime.fromtimestamp(mtime)
                })
    
    # Sort by modification time (newest first)
    folders.sort(key=lambda x: x["modified"], reverse=True)
    return folders


def load_fusion_export(json_path):
    """Load and parse Fusion 360 export JSON"""
    with open(json_path, 'r') as f:
        return json.load(f)


def load_mapping(export_folder):
    """Load existing ProShop mapping if it exists"""
    mapping_path = os.path.join(export_folder, "proshop_mapping.json")
    if os.path.exists(mapping_path):
        with open(mapping_path, 'r') as f:
            return json.load(f)
    return {}


def save_mapping(export_folder, mapping):
    """Save ProShop mapping for future use"""
    mapping_path = os.path.join(export_folder, "proshop_mapping.json")
    with open(mapping_path, 'w') as f:
        json.dump(mapping, f, indent=2)
    print(f"  ✓ Mapping saved to {mapping_path}")


def generate_written_description_html(setup_data, setup_index):
    """
    Generate HTML content for Written Description from Fusion export data.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    html_parts = []
    
    # Header with timestamp
    html_parts.append(f"<p><strong>Auto-generated from Fusion 360 - {timestamp}</strong></p>")
    html_parts.append("<hr>")
    
    # Setup name
    setup_name = setup_data.get("name", f"Setup {setup_index}")
    html_parts.append(f"<p><strong>Setup:</strong> {setup_name}</p>")
    
    # Operations list
    operations = setup_data.get("operations", [])
    if operations:
        html_parts.append("<p><strong>Operations:</strong></p>")
        html_parts.append("<ul>")
        for i, op in enumerate(operations, 1):
            tool = op.get("tool", {}) or {}
            tool_num = tool.get("number", "?")
            tool_id = tool.get("product_id", "") or tool.get("description", "")
            op_name = op.get("name", "")
            html_parts.append(f"<li>[T{tool_num}] {op_name}</li>")
        html_parts.append("</ul>")
    
    return "\n".join(html_parts)


def generate_sequence_details(setup_data, convert_to_inches=True):
    """
    Generate sequence detail records from Fusion export data.
    
    Args:
        setup_data: Dict with setup info from Fusion export
        convert_to_inches: If True, convert OOH from cm to inches (Fusion uses cm internally)
    
    Returns:
        List of dicts ready for ProShop API
    """
    tools_list = []
    
    for i, op in enumerate(setup_data.get("operations", []), 1):
        tool = op.get("tool", {}) or {}
        
        # Get tool ID - prefer product_id, fallback to description
        tool_id = tool.get("product_id", "") or tool.get("description", "") or "-"
        # Sanitize: replace spaces with underscores, slashes with dashes
        tool_id = tool_id.replace(" ", "_").replace("/", "-")
        
        # Get OOH from body_length (Fusion's "Length below holder")
        ooh = tool.get("body_length", 0) or 0
        
        # Convert cm to inches (Fusion exports in cm internally)
        if convert_to_inches and ooh > 0:
            ooh = ooh / 2.54
        
        # Get holder
        holder = tool.get("holder_description", "") or tool.get("holder_id", "") or "-"
        holder = holder.replace(" ", "_") if holder else "-"
        
        # Operation description
        desc = op.get("name", "")
        
        tools_list.append({
            "sequenceNumber": str(i),
            "tool": tool_id,
            "outOfHolder": f"{ooh:.4f}" if isinstance(ooh, (int, float)) else str(ooh),
            "holder": holder if holder else "-",
            "sequenceDescription": desc
        })
    
    return tools_list


def push_setup_to_proshop(api, part_number, op_number, setup_data, setup_index):
    """
    Push a single setup's data to ProShop.
    """
    print(f"\n  Pushing '{setup_data.get('name')}' → Part {part_number} Op {op_number}")
    
    # 1. Generate and update Written Description
    print("    Updating Written Description...")
    html_content = generate_written_description_html(setup_data, setup_index)
    try:
        api.update_written_description(part_number, op_number, html_content, prepend=True)
        print("    ✓ Written Description updated")
    except Exception as e:
        print(f"    ✗ Written Description failed: {e}")
        return False
    
    # 2. Generate and update Sequence Details
    print("    Updating Sequence Details...")
    tools_list = generate_sequence_details(setup_data)
    if tools_list:
        try:
            api.update_multiple_sequence_details(part_number, op_number, tools_list)
            print(f"    ✓ {len(tools_list)} sequence details updated")
        except Exception as e:
            print(f"    ✗ Sequence Details failed: {e}")
            return False
    else:
        print("    (No operations to push)")
    
    return True


# =============================================================================
# INTERACTIVE MODE
# =============================================================================

def select_export_folder():
    """Let user select an export folder"""
    folders = list_export_folders()
    
    if not folders:
        print("\nNo exports found in:")
        print(f"  {EXPORTS_FOLDER}")
        print("\nRun ExportToProShop in Fusion 360 first.")
        return None
    
    print("\n" + "=" * 60)
    print("Available Exports (newest first)")
    print("=" * 60)
    
    for i, folder in enumerate(folders, 1):
        age = datetime.now() - folder["modified"]
        if age.days > 0:
            age_str = f"{age.days}d ago"
        elif age.seconds > 3600:
            age_str = f"{age.seconds // 3600}h ago"
        else:
            age_str = f"{age.seconds // 60}m ago"
        
        print(f"  {i}. {folder['name']} ({age_str})")
    
    print()
    choice = input("Select export [1]: ").strip() or "1"
    
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(folders):
            return folders[idx]
    except ValueError:
        pass
    
    print("Invalid selection")
    return None


def interactive_mapping(export_data, existing_mapping):
    """
    Interactively map setups to ProShop part/op numbers.
    Returns updated mapping dict.
    """
    setups = export_data.get("setups", [])
    mapping = existing_mapping.copy()
    
    print("\n" + "=" * 60)
    print("Setup → ProShop Mapping")
    print("=" * 60)
    
    if mapping:
        print("\nExisting mapping found. Press Enter to keep, or enter new value.")
    
    print("\nFormat: part_number:op_number (e.g., TRA1-TEMP:60)")
    print("Enter 'skip' to skip a setup, 'done' when finished.\n")
    
    for i, setup in enumerate(setups):
        setup_name = setup.get("name", f"Setup {i+1}")
        op_count = len(setup.get("operations", []))
        
        existing = mapping.get(setup_name, {})
        existing_str = ""
        if existing:
            existing_str = f" [{existing.get('part', '')}:{existing.get('op', '')}]"
        
        print(f"{i+1}. {setup_name} ({op_count} ops){existing_str}")
        
        user_input = input("   Part-Op: ").strip().lower()
        
        if user_input == "done":
            break
        elif user_input == "skip" or user_input == "s":
            if setup_name in mapping:
                del mapping[setup_name]
            continue
        elif user_input == "" and existing:
            # Keep existing mapping
            continue
        elif ":" in user_input:
            parts = user_input.split(":", 1)
            mapping[setup_name] = {
                "part": parts[0].strip(),
                "op": parts[1].strip()
            }
        elif user_input:
            print("   Invalid format. Use: part_number:op_number")
    
    return mapping


def batch_push(api, export_data, mapping):
    """Push all mapped setups to ProShop"""
    setups = export_data.get("setups", [])
    
    print("\n" + "=" * 60)
    print("Pushing to ProShop")
    print("=" * 60)
    
    success_count = 0
    skip_count = 0
    fail_count = 0
    
    for i, setup in enumerate(setups):
        setup_name = setup.get("name", f"Setup {i+1}")
        
        if setup_name not in mapping:
            print(f"\n  Skipping '{setup_name}' (not mapped)")
            skip_count += 1
            continue
        
        part_num = mapping[setup_name].get("part")
        op_num = mapping[setup_name].get("op")
        
        if not part_num or not op_num:
            print(f"\n  Skipping '{setup_name}' (incomplete mapping)")
            skip_count += 1
            continue
        
        if push_setup_to_proshop(api, part_num, op_num, setup, i + 1):
            success_count += 1
        else:
            fail_count += 1
    
    print("\n" + "-" * 40)
    print(f"Complete: {success_count} pushed, {skip_count} skipped, {fail_count} failed")
    
    return success_count, skip_count, fail_count


def main():
    print("=" * 60)
    print("ProShop GraphQL API Client v2.0")
    print("=" * 60)
    
    # 1. Select export folder
    folder = select_export_folder()
    if not folder:
        return
    
    print(f"\nLoading: {folder['name']}")
    export_data = load_fusion_export(folder["json_path"])
    
    setups = export_data.get("setups", [])
    total_ops = sum(len(s.get("operations", [])) for s in setups)
    print(f"  Found {len(setups)} setups, {total_ops} total operations")
    
    # 2. Load existing mapping
    existing_mapping = load_mapping(folder["path"])
    if existing_mapping:
        print(f"  Found existing mapping for {len(existing_mapping)} setups")
    
    # 3. Authenticate
    print("\n" + "-" * 40)
    print("ProShop Authentication")
    print("-" * 40)
    
    client_id = input(f"Client ID [{DEFAULT_CLIENT_ID}]: ").strip() or DEFAULT_CLIENT_ID
    client_secret = input("Client Secret: ").strip()
    
    if not client_secret:
        print("Client secret required.")
        return
    
    api = ProShopGraphQL()
    if not api.authenticate_oauth(client_id, client_secret):
        print("\nAuthentication failed.")
        return
    
    # 4. Interactive mapping
    mapping = interactive_mapping(export_data, existing_mapping)
    
    # Show summary
    mapped_count = len([s for s in setups if s.get("name") in mapping])
    print(f"\n{mapped_count} of {len(setups)} setups mapped.")
    
    if mapped_count == 0:
        print("Nothing to push.")
        return
    
    # 5. Confirm and push
    confirm = input("\nPush to ProShop? (y/n) [y]: ").strip().lower() or "y"
    if confirm != "y":
        print("Cancelled.")
        return
    
    # Save mapping before pushing
    save_mapping(folder["path"], mapping)
    
    # 6. Batch push
    batch_push(api, export_data, mapping)
    
    print("\nDone!")


if __name__ == "__main__":
    main()
