# ProShop Conversational Interface

A natural language interface for querying ProShop ERP at Traxis Manufacturing.

## Quick Start for Claude Code

1. **Add credentials** - Set environment variable:
   ```bash
   export PROSHOP_CLIENT_SECRET="your_secret_here"
   ```

2. **Run feasibility spike** - Let Claude Code run:
   ```bash
   python run_feasibility_spike.py
   ```

3. **Check results** - Review `results/00_GO_NO_GO.md` for recommendation

## Project Structure

```
├── PROJECT.md              # Full project brief (READ THIS FIRST)
├── README.md               # This file
├── run_feasibility_spike.py # Automated test runner
├── reference_code/         # Existing ProShop API code
├── results/                # Test results (generated)
└── src/                    # Implementation (Phase 1+)
```

## What This Does

Takes natural language queries like:
- "What's the status of WO 25-0001?"
- "Show me all open jobs for R2Sonic"
- "What parts are due this week?"

And translates them to ProShop GraphQL API calls, returning readable results.

## Credentials

Ask Wolfgang for the `PROSHOP_CLIENT_SECRET`. The client ID is already configured:
- Client ID: `3923-9C1C-7291`
- Endpoint: `https://traxismfg.adionsystems.com/api/graphql`

## For Claude Code

Read `PROJECT.md` first - it contains:
- Full technical context
- Step-by-step test regime
- Implementation phases
- Stop conditions and error handling
